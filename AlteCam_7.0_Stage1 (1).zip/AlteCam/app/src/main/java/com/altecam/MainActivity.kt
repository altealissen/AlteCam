package com.altecam

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private enum class CaptureMode { PHOTO, HDR, NIGHT, BOOST }

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var captureButton: Button
    private lateinit var status: TextView
    private lateinit var exposureLabel: TextView
    private lateinit var zoomLabel: TextView
    private lateinit var executor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private var camera: Camera? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var mode = CaptureMode.PHOTO
    private var exposureIndex = 0
    private var zoomRatio = 1f
    private var busy = false

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else toast("Для работы Alte Cam нужен доступ к камере")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        executor = Executors.newSingleThreadExecutor()
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "Alte Cam 7.0"; textSize = 23f; setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.create("sans-serif-medium", 0)
        }
        status = TextView(this).apply { text = "PIXEL COMPUTATIONAL CAMERA"; textSize = 9f; letterSpacing = .08f; setTextColor(0xFFD0BCFF.toInt()); gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(44), 1f))
        header.addView(status)
        panel.addView(header)
        panel.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

        val settings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(10))
            background = rounded(0x990F1014.toInt(), 24)
        }
        exposureLabel = TextView(this).apply { text = "Экспозиция  0 EV"; setTextColor(Color.WHITE); textSize = 12f }
        settings.addView(exposureLabel)
        val exposure = SeekBar(this).apply {
            max = 24; progress = 12
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val range = camera?.cameraInfo?.exposureState?.exposureCompensationRange
                    val steps = range?.upper ?: 12
                    exposureIndex = ((progress - 12) * steps / 12).coerceIn(range?.lower ?: -12, range?.upper ?: 12)
                    exposureLabel.text = "Экспозиция  ${"%.1f".format(Locale.US, exposureIndex * (camera?.cameraInfo?.exposureState?.exposureCompensationStep?.toFloat() ?: 0.333f))} EV"
                    if (fromUser) camera?.cameraControl?.setExposureCompensationIndex(exposureIndex)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        settings.addView(exposure, LinearLayout.LayoutParams(-1, dp(34)))
        zoomLabel = TextView(this).apply { text = "Зум  1.0×"; setTextColor(Color.WHITE); textSize = 12f }
        settings.addView(zoomLabel)
        val zoom = SeekBar(this).apply {
            max = 30; progress = 0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val maxZoom = camera?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 8f
                    zoomRatio = 1f + (maxZoom - 1f) * progress / 30f
                    zoomLabel.text = "Зум  ${"%.1f".format(Locale.US, zoomRatio)}×"
                    if (fromUser) camera?.cameraControl?.setZoomRatio(zoomRatio)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        settings.addView(zoom, LinearLayout.LayoutParams(-1, dp(34)))
        panel.addView(settings)

        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(8)) }
        listOf(
            "PHOTO" to CaptureMode.PHOTO,
            "HDR" to CaptureMode.HDR,
            "NIGHT" to CaptureMode.NIGHT,
            "BOOST" to CaptureMode.BOOST
        ).forEach { (label, value) ->
            val b = Button(this).apply {
                text = label; textSize = 10f; minWidth = 0; setPadding(dp(4), 0, dp(4), 0)
                setTextColor(if (mode == value) 0xFFD0BCFF.toInt() else Color.WHITE)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xAA22232A.toInt()))
                setOnClickListener { mode = value; refreshModeButtons(modes); status.text = modeDescription() }
            }
            modes.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        panel.addView(modes)

        val rawButton = Button(this).apply {
            text = "RAW DNG • EXPERT CAPTURE"
            textSize = 11f
            setTextColor(0xFFD0BCFF.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xAA22232A.toInt()))
            setOnClickListener { startActivity(Intent(this@MainActivity, RawCaptureActivity::class.java)) }
        }
        panel.addView(rawButton, LinearLayout.LayoutParams(-1, dp(44)).apply {
            setMargins(0, dp(2), 0, dp(4))
        })

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val flip = Button(this).apply { text = "↻"; textSize = 22f; setOnClickListener { switchCamera() } }
        captureButton = Button(this).apply {
            text = "●"; textSize = 30f; setTextColor(0xFF211B2B.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFD0BCFF.toInt()))
            setOnClickListener { captureSequence() }
        }
        val gallery = Button(this).apply { text = "▧"; textSize = 22f; setOnClickListener { toast("Снимки: Галерея → Pictures → Alte Cam") } }
        controls.addView(flip, LinearLayout.LayoutParams(dp(76), dp(64)))
        controls.addView(captureButton, LinearLayout.LayoutParams(dp(104), dp(72)))
        controls.addView(gallery, LinearLayout.LayoutParams(dp(76), dp(64)))
        panel.addView(controls)
        root.addView(panel, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun refreshModeButtons(row: LinearLayout) {
        for (i in 0 until row.childCount) {
            val button = row.getChildAt(i) as Button
            val selected = button.text.toString() == mode.name
            button.setTextColor(if (selected) 0xFFD0BCFF.toInt() else Color.WHITE)
        }
    }

    private fun modeDescription() = when (mode) {
        CaptureMode.PHOTO -> "STANDARD PHOTO"
        CaptureMode.HDR -> "3-FRAME EXPOSURE FUSION"
        CaptureMode.NIGHT -> "4-FRAME LOW-LIGHT AVERAGING"
        CaptureMode.BOOST -> "BOOST DETAIL + DENOISE"
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).setJpegQuality(100).build()
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, CameraSelector.Builder().requireLensFacing(lensFacing).build(), preview, imageCapture)
                val range = camera?.cameraInfo?.exposureState?.exposureCompensationRange
                status.text = if (range != null) "PIXEL CAMERA • EV ${range.lower}…${range.upper}" else "PIXEL CAMERA"
            } catch (e: Exception) { toast("Ошибка запуска камеры: ${e.localizedMessage}") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun switchCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        startCamera()
    }

    private fun captureSequence() {
        if (busy) return
        val cap = imageCapture ?: run { toast("Камера ещё запускается"); return }
        busy = true; captureButton.isEnabled = false; status.text = "CAPTURING…"
        val expRange = camera?.cameraInfo?.exposureState?.exposureCompensationRange
        val bracket = when (mode) {
            CaptureMode.HDR -> {
                val stepEv = camera?.cameraInfo?.exposureState?.exposureCompensationStep?.toFloat() ?: (1f / 3f)
                val twoEvSteps = kotlin.math.round(2f / stepEv).toInt().coerceAtLeast(1)
                listOf(-twoEvSteps, 0, twoEvSteps).map { (exposureIndex + it).coerceIn(expRange?.lower ?: -6, expRange?.upper ?: 6) }
            }
            CaptureMode.NIGHT -> listOf(0, 0, 0, 0)
            else -> listOf(exposureIndex)
        }
        val frames = mutableListOf<Bitmap>()
        captureFrameAt(cap, bracket, 0, frames) {
            camera?.cameraControl?.setExposureCompensationIndex(exposureIndex)
            executor.execute {
                try {
                    val result = when (mode) {
                        CaptureMode.HDR -> FrameFusion.hdr(frames)
                        CaptureMode.NIGHT -> FrameFusion.average(frames)
                        CaptureMode.BOOST -> BoostProcessor.enhance(frames.first())
                        CaptureMode.PHOTO -> frames.first()
                    }
                    saveBitmap(result)
                    if (frames.none { it === result }) result.recycle()
                    frames.forEach { if (!it.isRecycled) it.recycle() }
                    runOnUiThread {
                        busy = false; captureButton.isEnabled = true
                        status.text = when (mode) {
                            CaptureMode.HDR -> "HDR FUSION SAVED"
                            CaptureMode.NIGHT -> "NIGHT STACK SAVED"
                            CaptureMode.BOOST -> "BOOST COMPLETE"
                            CaptureMode.PHOTO -> "PHOTO SAVED"
                        }
                        toast("Снимок сохранён в Pictures/Alte Cam")
                    }
                } catch (e: Exception) {
                    frames.forEach { if (!it.isRecycled) it.recycle() }
                    runOnUiThread { busy = false; captureButton.isEnabled = true; status.text = "PROCESSING ERROR"; toast("Ошибка обработки: ${e.localizedMessage}") }
                }
            }
        }
    }

    private fun captureFrameAt(cap: ImageCapture, bracket: List<Int>, index: Int, frames: MutableList<Bitmap>, done: () -> Unit) {
        if (index >= bracket.size) { done(); return }
        val target = bracket[index]
        val future = camera?.cameraControl?.setExposureCompensationIndex(target)
        if (future == null) { captureSingle(cap, bracket, index, frames, done); return }
        future.addListener({ captureSingle(cap, bracket, index, frames, done) }, ContextCompat.getMainExecutor(this))
    }

    private fun captureSingle(cap: ImageCapture, bracket: List<Int>, index: Int, frames: MutableList<Bitmap>, done: () -> Unit) {
        cap.takePicture(ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining()); buffer.get(bytes)
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                    val maxSide = if (mode == CaptureMode.PHOTO) 0 else 1920
                    val sample = if (maxSide == 0) 1 else {
                        var n = 1
                        while (maxOf(bounds.outWidth / n, bounds.outHeight / n) > maxSide) n *= 2
                        n
                    }
                    val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 })
                    if (decoded != null) {
                        val rotation = image.imageInfo.rotationDegrees
                        val bitmap = if (rotation != 0) {
                            val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, Matrix().apply { postRotate(rotation.toFloat()) }, true)
                            if (rotated !== decoded) decoded.recycle()
                            rotated
                        } else decoded
                        frames.add(bitmap)
                    }
                } finally { image.close() }
                if (frames.size == index + 1) captureFrameAt(cap, bracket, index + 1, frames, done)
                else { busy = false; runOnUiThread { captureButton.isEnabled = true; toast("Не удалось декодировать кадр") } }
            }
            override fun onError(exception: ImageCaptureException) {
                camera?.cameraControl?.setExposureCompensationIndex(exposureIndex)
                busy = false; runOnUiThread { captureButton.isEnabled = true; status.text = "CAPTURE ERROR"; toast("Ошибка съёмки: ${exception.message}") }
            }
        })
    }

    private fun saveBitmap(bitmap: Bitmap) {
        val name = "ALTE_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Alte Cam")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("MediaStore insert failed")
        contentResolver.openOutputStream(uri)?.use { out ->
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 96, out)) error("JPEG encode failed")
        } ?: error("Cannot open output stream")
    }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onDestroy() { super.onDestroy(); executor.shutdown() }
}

/**
 * Global translational alignment + robust multi-frame fusion.
 * This is a practical lightweight approximation, not optical-flow alignment.
 */
private object FrameFusion {
    fun average(frames: List<Bitmap>): Bitmap = fuse(frames, hdr = false)
    fun hdr(frames: List<Bitmap>): Bitmap = fuse(frames, hdr = true)

    private fun fuse(frames: List<Bitmap>, hdr: Boolean): Bitmap {
        require(frames.isNotEmpty())
        if (frames.size == 1) return BoostProcessor.enhance(frames[0])
        val w = frames.minOf { it.width }
        val h = frames.minOf { it.height }
        val normalized = frames.map { b ->
            if (b.width == w && b.height == h) b else Bitmap.createScaledBitmap(b, w, h, true)
        }
        val ref = normalized[normalized.size / 2]
        val refPixels = IntArray(w * h).also { ref.getPixels(it, 0, w, 0, 0, w, h) }
        val aligned = normalized.mapIndexed { index, bitmap ->
            if (index == normalized.size / 2) refPixels else {
                val pixels = IntArray(w * h).also { bitmap.getPixels(it, 0, w, 0, 0, w, h) }
                val shift = estimateTranslation(refPixels, pixels, w, h)
                translate(pixels, w, h, shift.first, shift.second)
            }
        }
        val output = IntArray(w * h)
        val centerFrame = aligned[aligned.size / 2]
        for (i in output.indices) {
            val center = centerFrame[i]
            val cr = Color.red(center).toDouble()
            val cg = Color.green(center).toDouble()
            val cb = Color.blue(center).toDouble()
            val centerLum = .2126 * cr + .7152 * cg + .0722 * cb
            var r = 0.0; var g = 0.0; var b = 0.0; var total = 0.0
            for (frame in aligned) {
                val c = frame[i]
                val pr = Color.red(c).toDouble(); val pg = Color.green(c).toDouble(); val pb = Color.blue(c).toDouble()
                val lum = .2126 * pr + .7152 * pg + .0722 * pb
                val motionDiff = abs(lum - centerLum)
                // Reject likely moving-object pixels instead of blending ghost trails.
                val motionWeight = 1.0 / (1.0 + (motionDiff / 22.0).pow(2.0))
                val exposureWeight = if (hdr) {
                    val normalizedLum = lum / 255.0
                    max(.08, 1.0 - abs(normalizedLum - .48) * 1.75)
                } else 1.0
                val weight = motionWeight * exposureWeight
                r += pr * weight; g += pg * weight; b += pb * weight; total += weight
            }
            val rr = (r / total).coerceIn(0.0, 255.0).toInt()
            val gg = (g / total).coerceIn(0.0, 255.0).toInt()
            val bb = (b / total).coerceIn(0.0, 255.0).toInt()
            output[i] = if (hdr) toneMap(rr, gg, bb) else Color.rgb(rr, gg, bb)
        }
        val fused = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        fused.setPixels(output, 0, w, 0, 0, w, h)
        normalized.forEach { if (it !== ref && frames.none { original -> original === it }) it.recycle() }
        return BoostProcessor.enhance(fused).also { if (it !== fused) fused.recycle() }
    }

    private fun estimateTranslation(reference: IntArray, candidate: IntArray, w: Int, h: Int): Pair<Int, Int> {
        val scale = maxOf(1, maxOf(w, h) / 320)
        val radius = maxOf(2, 8 / scale)
        var bestX = 0; var bestY = 0; var best = Double.MAX_VALUE
        val step = maxOf(2, 5 * scale)
        for (dy in -radius..radius) for (dx in -radius..radius) {
            var error = 0.0; var count = 0
            var y = 12 * scale
            while (y < h - 12 * scale) {
                var x = 12 * scale
                while (x < w - 12 * scale) {
                    val a = reference[y * w + x]; val b = candidate[(y + dy * scale).coerceIn(0, h - 1) * w + (x + dx * scale).coerceIn(0, w - 1)]
                    val la = .2126 * Color.red(a) + .7152 * Color.green(a) + .0722 * Color.blue(a)
                    val lb = .2126 * Color.red(b) + .7152 * Color.green(b) + .0722 * Color.blue(b)
                    error += abs(la - lb); count++
                    x += step
                }
                y += step
            }
            val score = if (count == 0) Double.MAX_VALUE else error / count
            if (score < best) { best = score; bestX = dx * scale; bestY = dy * scale }
        }
        return Pair(bestX, bestY)
    }

    private fun translate(src: IntArray, w: Int, h: Int, dx: Int, dy: Int): IntArray {
        val out = IntArray(src.size)
        for (y in 0 until h) for (x in 0 until w) {
            val sx = (x + dx).coerceIn(0, w - 1)
            val sy = (y + dy).coerceIn(0, h - 1)
            out[y * w + x] = src[sy * w + sx]
        }
        return out
    }

    private fun toneMap(r: Int, g: Int, b: Int): Int {
        fun map(v: Int): Int {
            val x = v / 255.0
            val compressed = (x * (1.0 + 0.18)) / (x + 0.18)
            return (compressed * 255.0).coerceIn(0.0, 255.0).toInt()
        }
        return Color.rgb(map(r), map(g), map(b))
    }
}

/** Conservative spatial enhancement; not a trained neural network. */
private object BoostProcessor {
    fun enhance(source: Bitmap): Bitmap {
        val w = source.width; val h = source.height
        val src = IntArray(w * h); source.getPixels(src, 0, w, 0, 0, w, h)
        val out = src.copyOf()
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x; val c = src[i]
            val cr = Color.red(c); val cg = Color.green(c); val cb = Color.blue(c)
            var rr = 0.0; var gg = 0.0; var bb = 0.0; var total = 0.0
            for (dy in -1..1) for (dx in -1..1) {
                val p = src[(y + dy) * w + x + dx]
                val dist = (abs(Color.red(p) - cr) + abs(Color.green(p) - cg) + abs(Color.blue(p) - cb)) / 3.0
                val wt = if (dx == 0 && dy == 0) 1.0 else 1.0 / (1.0 + dist / 24.0)
                rr += Color.red(p) * wt; gg += Color.green(p) * wt; bb += Color.blue(p) * wt; total += wt
            }
            fun sharpen(center: Double, a: Int, b: Int, d: Int, e: Int, channel: (Int) -> Int): Int =
                (center + (4 * center - channel(a) - channel(b) - channel(d) - channel(e)) * 0.28).coerceIn(0.0, 255.0).toInt()
            val r0 = (rr / total).toInt(); val g0 = (gg / total).toInt(); val b0 = (bb / total).toInt()
            val lum = .2126 * r0 + .7152 * g0 + .0722 * b0
            val sat = 1.045
            val r = (lum + (sharpen(r0.toDouble(), src[i-1], src[i+1], src[i-w], src[i+w], Color::red) - lum) * sat).toInt().coerceIn(0,255)
            val g = (lum + (sharpen(g0.toDouble(), src[i-1], src[i+1], src[i-w], src[i+w], Color::green) - lum) * sat).toInt().coerceIn(0,255)
            val b = (lum + (sharpen(b0.toDouble(), src[i-1], src[i+1], src[i-w], src[i+w], Color::blue) - lum) * sat).toInt().coerceIn(0,255)
            out[i] = Color.rgb(r,g,b)
        }
        return Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888).also { it.setPixels(out,0,w,0,0,w,h) }
    }
}
