package com.altecam.engine

/**
 * Bayer demosaicing with the Malvar-He-Cutler (2004) 5x5 gradient-corrected
 * linear filters. Borders use mirrored indexing (parity-preserving), so there
 * is no special-case seam. Works on any of the four CFA layouts.
 */
object DemosaicEngine {

    private fun mirror(i: Int, n: Int): Int = when {
        i < 0 -> -i
        i >= n -> 2 * (n - 1) - i
        else -> i
    }

    /**
     * Demosaics one row. [out] receives interleaved linear R,G,B (3*width floats).
     * @param bayer width*height normalised mosaic
     */
    fun demosaicRow(bayer: FloatArray, w: Int, h: Int, cfa: CfaPattern, y: Int, out: FloatArray) {
        val r = IntArray(5) { mirror(y + it - 2, h) * w }
        val xi = IntArray(w + 4) { mirror(it - 2, w) }
        for (x in 0 until w) {
            val c = cfa.colorAt(x, y)
            val xm1 = xi[x + 1]; val xp1 = xi[x + 3]; val xm2 = xi[x]; val xp2 = xi[x + 4]
            val cx = xi[x + 2]
            val center = bayer[r[2] + cx]
            val left = bayer[r[2] + xm1]; val right = bayer[r[2] + xp1]
            val up = bayer[r[1] + cx]; val down = bayer[r[3] + cx]
            val left2 = bayer[r[2] + xm2]; val right2 = bayer[r[2] + xp2]
            val up2 = bayer[r[0] + cx]; val down2 = bayer[r[4] + cx]
            val ul = bayer[r[1] + xm1]; val ur = bayer[r[1] + xp1]
            val dl = bayer[r[3] + xm1]; val dr = bayer[r[3] + xp1]
            var R: Float; var G: Float; var B: Float
            when (c) {
                1 -> { // green site: is the horizontal neighbour red or blue?
                    G = center
                    val horizRed = cfa.colorAt(x + 1, y) == 0
                    // 5-tap kernels from the paper (/8)
                    val diag = ul + ur + dl + dr
                    val horiz = 4f * (left + right) - (left2 + right2) // used when horizontal neighbours are the wanted colour
                    val vert = 4f * (up + down) - (up2 + down2)
                    val hv = (5f * center + horiz + 0.5f * (up2 + down2) - diag) / 8f
                    val vh = (5f * center + vert + 0.5f * (left2 + right2) - diag) / 8f
                    if (horizRed) { R = hv; B = vh } else { B = hv; R = vh }
                }
                else -> { // red or blue site
                    val diag = ul + ur + dl + dr
                    val cross = up + down + left + right
                    G = (4f * center + 2f * cross - (up2 + down2 + left2 + right2)) / 8f
                    val opp = (6f * center + 2f * diag - 1.5f * (up2 + down2 + left2 + right2)) / 8f
                    if (c == 0) { R = center; B = opp } else { B = center; R = opp }
                }
            }
            out[3 * x] = R; out[3 * x + 1] = G; out[3 * x + 2] = B
        }
    }
}
