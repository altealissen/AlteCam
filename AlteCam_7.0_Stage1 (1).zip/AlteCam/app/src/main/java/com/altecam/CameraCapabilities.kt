package com.altecam

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.os.Build
import android.os.PowerManager
import com.altecam.engine.CfaPattern
import com.altecam.engine.RawMeta

/** Builds engine metadata from real Camera2 characteristics/results (no assumed values). */
object RawMetaFactory {
    fun create(c: CameraCharacteristics, r: TotalCaptureResult): RawMeta {
        val cfa = CfaPattern.fromCamera2(
            c.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT) ?: error("No CFA arrangement")
        )
        val white = (c.get(CameraCharacteristics.SENSOR_INFO_WHITE_LEVEL) ?: 1023).toFloat()
        val black = FloatArray(4)
        val dynamic = r.get(CaptureResult.SENSOR_DYNAMIC_BLACK_LEVEL)
        val pattern = c.get(CameraCharacteristics.SENSOR_BLACK_LEVEL_PATTERN)
        for (row in 0..1) for (col in 0..1) {
            val i = row * 2 + col
            black[i] = when {
                dynamic != null && dynamic.size >= 4 -> dynamic[i]
                pattern != null -> pattern.getOffsetForIndex(col, row).toFloat()
                else -> 0f
            }
        }
        // Noise profile: (S, O) per CFA channel, assumed to follow CFA position order.
        val np = r.get(CaptureResult.SENSOR_NOISE_PROFILE)
        var s: FloatArray? = null
        var o: FloatArray? = null
        if (np != null && np.size >= 4) {
            s = FloatArray(4) { np[it].first.toFloat() }
            o = FloatArray(4) { np[it].second.toFloat() }
        }
        val g = r.get(CaptureResult.COLOR_CORRECTION_GAINS)
        val gains = if (g != null) floatArrayOf(g.red, (g.greenEven + g.greenOdd) / 2f, g.blue) else floatArrayOf(1f, 1f, 1f)
        val t = r.get(CaptureResult.COLOR_CORRECTION_TRANSFORM)
        val ccm = t?.let { FloatArray(9) { i -> it.getElement(i % 3, i / 3).toFloat() } }
        return RawMeta(
            cfa, black, white,
            r.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: 10_000_000L,
            r.get(CaptureResult.SENSOR_SENSITIVITY) ?: 100,
            s, o, gains, ccm
        )
    }
}

/** What the device really offers; shown in the UI, nothing is assumed from "Google Camera has it". */
data class CameraReport(
    val id: String,
    val facing: String,
    val hardwareLevel: String,
    val raw: Boolean,
    val burst: Boolean,
    val manualSensor: Boolean,
    val rawSizes: List<String>,
    val isoRange: String,
    val exposureRangeMs: String,
    val fpsRanges: String,
    val sensorSize: String,
    val stabilization: String
) {
    fun text(): String = buildString {
        appendLine("Camera $id ($facing) • level $hardwareLevel • sensor $sensorSize")
        appendLine("  RAW=$raw  BURST=$burst  MANUAL_SENSOR=$manualSensor")
        appendLine("  RAW sizes: ${rawSizes.joinToString()}")
        appendLine("  ISO $isoRange  exposure $exposureRangeMs ms  FPS $fpsRanges  stabilization $stabilization")
    }
}

object CameraCapabilities {
    fun probe(context: Context): List<CameraReport> {
        val mgr = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        return mgr.cameraIdList.mapNotNull { id ->
            try { describe(id, mgr.getCameraCharacteristics(id)) } catch (_: Exception) { null }
        }
    }

    private fun describe(id: String, c: CameraCharacteristics): CameraReport {
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toList().orEmpty()
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val iso = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val exp = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val size = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
            CameraCharacteristics.LENS_FACING_BACK -> "back"
            CameraCharacteristics.LENS_FACING_FRONT -> "front"
            else -> "external"
        }
        val level = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "EXTERNAL"
            else -> "?"
        }
        val stab = buildList {
            if (c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.contains(1) == true) add("video-EIS")
            if (c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.contains(1) == true) add("OIS")
        }.ifEmpty { listOf("none") }.joinToString("+")
        return CameraReport(
            id, facing, level,
            raw = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW),
            burst = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BURST_CAPTURE),
            manualSensor = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR),
            rawSizes = map?.getOutputSizes(ImageFormat.RAW_SENSOR)?.map { "${it.width}x${it.height}" }.orEmpty(),
            isoRange = iso?.let { "${it.lower}-${it.upper}" } ?: "n/a",
            exposureRangeMs = exp?.let { "%.3f-%.0f".format(it.lower / 1e6, it.upper / 1e6) } ?: "n/a",
            fpsRanges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.joinToString { "${it.lower}-${it.upper}" } ?: "n/a",
            sensorSize = size?.let { "%.2fx%.2f mm".format(it.width, it.height) } ?: "n/a",
            stabilization = stab
        )
    }

    /** Free heap the app may still allocate. */
    fun freeHeapBytes(): Long {
        val rt = Runtime.getRuntime()
        return rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())
    }

    fun thermalStatus(context: Context): Int =
        if (Build.VERSION.SDK_INT >= 29) (context.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus else 0

    fun deviceSummary(context: Context): String {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val vulkan = context.packageManager.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL)
        return "${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE} • RAM ${mi.totalMem shr 20} MB • " +
            "heap ${Runtime.getRuntime().maxMemory() shr 20} MB • Vulkan=$vulkan • thermal=${thermalStatus(context)}"
    }
}
