package com.altecam.engine

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

class DevelopOptions(
    /** Auto exposure bounds (linear gain). Night scenes must not be turned into day. */
    val minAutoGain: Float = 0.7f,
    val maxAutoGain: Float = 3.0f,
    /** Fixed exposure in EV; null = automatic. */
    val exposureEv: Float? = null,
    /** 0 disables local tone mapping. */
    val shadowLift: Float = 0.4f,
    val maxShadowBoost: Float = 3.0f,
    val whitePoint: Float = 2.0f,
    val want16Bit: Boolean = false
)

class DevelopedImage(val width: Int, val height: Int, val argb: IntArray, val rgb16: ShortArray?, val appliedGain: Float)

/** White balance + sensor->sRGB colour matrix. */
object ColorScienceEngine {
    /** Returns gains normalised so G = 1. */
    fun normalisedGains(m: RawMeta): FloatArray {
        val g = m.wbGains[1]
        return floatArrayOf(m.wbGains[0] / g, 1f, m.wbGains[2] / g)
    }

    fun ccm(m: RawMeta): FloatArray = m.ccm ?: floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f)

    /** In-place: WB gains with clip-to-white, then CCM, negatives clamped. */
    fun apply(rgb: FloatArray, off: Int, gains: FloatArray, ccm: FloatArray) {
        val r = min(1f, rgb[off] * gains[0]).coerceAtLeast(0f)
        val g = min(1f, rgb[off + 1] * gains[1]).coerceAtLeast(0f)
        val b = min(1f, rgb[off + 2] * gains[2]).coerceAtLeast(0f)
        rgb[off] = max(0f, ccm[0] * r + ccm[1] * g + ccm[2] * b)
        rgb[off + 1] = max(0f, ccm[3] * r + ccm[4] * g + ccm[5] * b)
        rgb[off + 2] = max(0f, ccm[6] * r + ccm[7] * g + ccm[8] * b)
    }
}

/** sRGB transfer + global/local tone mapping. */
object ToneMappingEngine {
    private const val LUT_SIZE = 4096
    private val srgbLut = FloatArray(LUT_SIZE + 1) { i ->
        val v = i / LUT_SIZE.toFloat()
        if (v <= 0.0031308f) 12.92f * v else (1.055 * v.toDouble().pow(1 / 2.4) - 0.055).toFloat()
    }

    fun srgbEncode(v: Float): Float {
        if (v <= 0f) return 0f
        if (v >= 1f) return 1f
        val p = v * LUT_SIZE
        val i = p.toInt()
        return srgbLut[i] + (srgbLut[i + 1] - srgbLut[i]) * (p - i)
    }

    /** Extended Reinhard on scene luminance; keeps colour ratios. */
    fun curve(l: Float, white: Float): Float = l * (1f + l / (white * white)) / (1f + l)

    /**
     * Edge-preserving base layer (bilateral filter on a small log2-luminance map).
     * Range weighting stops the base from bleeding across strong edges (reduces halos).
     */
    fun bilateralBase(logL: FloatArray, w: Int, h: Int, radius: Int = 5, rangeSigma: Float = 0.7f): FloatArray {
        val out = FloatArray(w * h)
        val inv2 = 1f / (2f * rangeSigma * rangeSigma)
        val sp = FloatArray(2 * radius + 1) { exp(-((it - radius) * (it - radius)) / (2f * (radius / 2f) * (radius / 2f))) }
        for (y in 0 until h) for (x in 0 until w) {
            val c = logL[y * w + x]
            var s = 0f; var ws = 0f
            for (dy in -radius..radius) {
                val yy = y + dy; if (yy < 0 || yy >= h) continue
                for (dx in -radius..radius) {
                    val xx = x + dx; if (xx < 0 || xx >= w) continue
                    val v = logL[yy * w + xx]
                    val d = v - c
                    val wt = sp[dy + radius] * sp[dx + radius] * exp(-d * d * inv2)
                    s += wt * v; ws += wt
                }
            }
            out[y * w + x] = s / ws
        }
        return out
    }
}

/**
 * Develops a fused (or single) normalised Bayer mosaic into an sRGB image:
 * block-statistics for exposure/local tone map -> per-row demosaic -> WB -> CCM
 * -> local shadow lift -> tone curve -> sRGB OETF. Streaming per row, so the
 * peak extra memory is the output arrays only.
 */
object RawDeveloper {
    private const val BLOCK = 8

    fun develop(
        bayer: FloatArray, w: Int, h: Int, meta: RawMeta,
        options: DevelopOptions = DevelopOptions(),
        progress: ProgressListener? = null,
        cancel: CancelToken? = null
    ): DevelopedImage {
        require(bayer.size == w * h)
        val cfa = meta.cfa
        val gains = ColorScienceEngine.normalisedGains(meta)
        val ccm = ColorScienceEngine.ccm(meta)

        // ---- low-res luminance map straight from the mosaic ------------------------
        val bw = w / BLOCK; val bh = h / BLOCK
        require(bw >= 2 && bh >= 2) { "Image too small" }
        val logL = FloatArray(bw * bh)
        val px = FloatArray(3)
        var sumLog = 0.0
        for (by in 0 until bh) for (bx in 0 until bw) {
            val sum = FloatArray(3); val n = IntArray(3)
            for (y in by * BLOCK until by * BLOCK + BLOCK) for (x in bx * BLOCK until bx * BLOCK + BLOCK) {
                val c = cfa.colorAt(x, y); sum[c] += bayer[y * w + x]; n[c]++
            }
            for (c in 0..2) px[c] = sum[c] / n[c]
            ColorScienceEngine.apply(px, 0, gains, ccm)
            val lum = 0.2126f * px[0] + 0.7152f * px[1] + 0.0722f * px[2]
            val l2 = ln(max(lum, 1e-4f)) / ln(2f)
            logL[by * bw + bx] = l2
            sumLog += l2
        }
        val geoMean = 2.0.pow(sumLog / logL.size).toFloat()
        val gain = options.exposureEv?.let { 2f.pow(it) } ?: (0.18f / max(geoMean, 1e-4f)).coerceIn(options.minAutoGain, options.maxAutoGain)
        val base = ToneMappingEngine.bilateralBase(logL, bw, bh)

        // ---- per-row development -------------------------------------------------------
        val argb = IntArray(w * h)
        val rgb16 = if (options.want16Bit) ShortArray(w * h * 3) else null
        val row = FloatArray(3 * w)
        val white = options.whitePoint
        for (y in 0 until h) {
            if ((y and 31) == 0) { cancel?.throwIfCancelled(); progress?.onProgress("Rendering", y / h.toFloat()) }
            DemosaicEngine.demosaicRow(bayer, w, h, cfa, y, row)
            // bilinear sample position in the block grid
            val fy = ((y + 0.5f) / BLOCK - 0.5f).coerceIn(0f, bh - 1.001f)
            val y0 = fy.toInt(); val ty = fy - y0
            for (x in 0 until w) {
                ColorScienceEngine.apply(row, 3 * x, gains, ccm)
                var r = row[3 * x] * gain; var g = row[3 * x + 1] * gain; var b = row[3 * x + 2] * gain
                if (options.shadowLift > 0f) {
                    val fx = ((x + 0.5f) / BLOCK - 0.5f).coerceIn(0f, bw - 1.001f)
                    val x0 = fx.toInt(); val tx = fx - x0
                    val i = y0 * bw + x0
                    val bl = (logL.let { base[i] * (1 - tx) + base[i + 1] * tx } * (1 - ty) +
                        (base[i + bw] * (1 - tx) + base[i + bw + 1] * tx) * ty)
                    val baseLin = 2f.pow(bl) * gain
                    val boost = (0.25f / max(baseLin, 1e-4f)).pow(options.shadowLift).coerceIn(1f, options.maxShadowBoost)
                    r *= boost; g *= boost; b *= boost
                }
                val lum = 0.2126f * r + 0.7152f * g + 0.0722f * b
                if (lum > 1e-6f) {
                    val s = ToneMappingEngine.curve(lum, white) / lum
                    r *= s; g *= s; b *= s
                }
                val mx = max(r, max(g, b))
                if (mx > 1f) { r /= mx; g /= mx; b /= mx }
                val er = ToneMappingEngine.srgbEncode(r); val eg = ToneMappingEngine.srgbEncode(g); val eb = ToneMappingEngine.srgbEncode(b)
                argb[y * w + x] = (0xFF shl 24) or ((er * 255f + .5f).toInt() shl 16) or ((eg * 255f + .5f).toInt() shl 8) or (eb * 255f + .5f).toInt()
                if (rgb16 != null) {
                    val o = (y * w + x) * 3
                    rgb16[o] = (er * 65535f + .5f).toInt().toShort()
                    rgb16[o + 1] = (eg * 65535f + .5f).toInt().toShort()
                    rgb16[o + 2] = (eb * 65535f + .5f).toInt().toShort()
                }
            }
        }
        progress?.onProgress("Rendering", 1f)
        return DevelopedImage(w, h, argb, rgb16, gain)
    }

    @Suppress("unused")
    private fun unusedAbs(v: Float) = abs(v)
}
