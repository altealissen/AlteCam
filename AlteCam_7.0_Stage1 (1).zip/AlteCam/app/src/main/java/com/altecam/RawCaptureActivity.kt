package com.altecam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.DngCreator
import android.hardware.camera2.TotalCaptureResult
import android.media.ExifInterface
import android.media.Image
import android.media.ImageReader
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.altecam.engine.BurstPlanner
import com.altecam.engine.CancelToken
import com.altecam.engine.DevelopOptions
import com.altecam.engine.FusionOptions
import com.altecam.engine.RawDeveloper
import com.altecam.engine.RawFrame
import com.altecam.engine.RawFusionEngine
import com.altecam.engine.TiffWriter
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CancellationException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * RAW_SENSOR burst -> original DNGs (kept untouched) -> Alte RawFusionEngine (own HDR+-style
 * implementation, not Google's) -> development -> JPEG (+ optional 16-bit TIFF).
 *
 * NOTE: written against the public Camera2 API but NOT compiled/run in the authoring
 * environment (no Android SDK / Pixel 8 available there). Verify on a device.
 */
class RawCaptureActivity : AppCompatActivity() {
    private lateinit var texture: TextureView
    private lateinit var status: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var capture: Button
    private lateinit var tiffToggle: Button
    private lateinit var cameraManager: CameraManager

    private var cameraDevice: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null
    private var characteristics: CameraCharacteristics? = null
    private var previewSurface: Surface? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var opening = false

    private val processor: ExecutorService = Executors.newSingleThreadExecutor()
    @Volatile private var cancelToken: CancelToken? = null
    @Volatile private var busy = false
    @Volatile private var saveTiff = false
    private var burstFrames = 5

    // ---- burst bookkeeping (guarded by lock) --------------------------------------------
    private val lock = Any()
    private val images = HashMap<Long, Image>()
    private val results = HashMap<Long, TotalCaptureResult>()
    private var expected = 0
    private var handedOff = false
    private var readerToClose: ImageReader? = null
    private var imagesInProcessing = false

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openCamera() else status.text = "CAMERA PERMISSION REQUIRED"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        buildUi()
        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) = openCamera()
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
        }
    }

    override fun onResume() {
        super.onResume()
        thread = HandlerThread("AlteCamRawCamera").also { it.start() }
        handler = Handler(thread!!.looper)
        if (texture.isAvailable) openCamera()
    }

    override fun onPause() {
        closeCamera()
        thread?.quitSafely()
        thread = null; handler = null
        super.onPause()
    }

    override fun onDestroy() {
        // let an already-running job finish saving; only stop the executor from accepting more
        processor.shutdown()
        super.onDestroy()
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        texture = TextureView(this)
        root.addView(texture, FrameLayout.LayoutParams(-1, -1))
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply { text = "Alte Cam • RAW"; textSize = 21f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, dp(48), 1f))
        status = TextView(this).apply {
            text = "SEARCHING RAW SENSOR…"; textSize = 10f; setTextColor(0xFFD0BCFF.toInt()); gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        top.addView(status)
        panel.addView(top)
        panel.addView(android.view.View(this), LinearLayout.LayoutParams(1, 0, 1f))
        panel.addView(TextView(this).apply {
            text = "HDR+-style RAW fusion (own algorithm): burst → align → robust merge → develop. Original DNGs are kept."
            textSize = 11f; setTextColor(Color.WHITE); setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(0x88202025.toInt())
        })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000; progress = 0 }
        panel.addView(progressBar, LinearLayout.LayoutParams(-1, dp(10)).apply { topMargin = dp(8) })
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) }
        val back = Button(this).apply { text = "BACK"; setOnClickListener { finish() } }
        tiffToggle = Button(this).apply {
            text = "TIFF OFF"; textSize = 11f
            setOnClickListener { saveTiff = !saveTiff; text = if (saveTiff) "TIFF ON" else "TIFF OFF" }
        }
        capture = Button(this).apply {
            text = "CAPTURE"
            setTextColor(0xFF211B2B.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFD0BCFF.toInt()))
            setOnClickListener { if (busy) cancelToken?.cancel() else captureBurst() }
        }
        row.addView(back, LinearLayout.LayoutParams(0, dp(58), 1f))
        row.addView(tiffToggle, LinearLayout.LayoutParams(0, dp(58), 1f))
        row.addView(capture, LinearLayout.LayoutParams(0, dp(58), 2f))
        panel.addView(row)
        root.addView(panel, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    // ---- camera lifecycle ---------------------------------------------------------------------

    private fun openCamera() {
        if (isFinishing || cameraDevice != null || opening || !texture.isAvailable) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
            return
        }
        val h = handler ?: return
        try {
            val id = cameraManager.cameraIdList.firstOrNull { candidate ->
                val c = cameraManager.getCameraCharacteristics(candidate)
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK &&
                    c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
                        ?.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW) == true
            } ?: run { status.text = "RAW SENSOR NOT AVAILABLE"; capture.isEnabled = false; return }
            val chars = cameraManager.getCameraCharacteristics(id)
            characteristics = chars
            val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(ImageFormat.RAW_SENSOR)
            if (sizes.isNullOrEmpty()) { status.text = "RAW FORMAT NOT AVAILABLE"; capture.isEnabled = false; return }
            // Prefer the largest RAW size up to 12 MP; BurstPlanner then limits the frame count to the memory budget.
            val rawSize = sizes.filter { it.width.toLong() * it.height <= 12_000_000L }.maxByOrNull { it.width.toLong() * it.height }
                ?: sizes.minByOrNull { it.width.toLong() * it.height }!!
            val previewSize = map?.getOutputSizes(SurfaceTexture::class.java)
                ?.minByOrNull { kotlin.math.abs(it.width - 1280) + kotlin.math.abs(it.height - 720) } ?: rawSize

            burstFrames = BurstPlanner.plan(5, rawSize.width.toLong() * rawSize.height, CameraCapabilities.freeHeapBytes(), CameraCapabilities.thermalStatus(this), saveTiff)
            if (burstFrames == 0) { status.text = "NOT ENOUGH MEMORY OR DEVICE TOO HOT"; capture.isEnabled = false; return }

            imageReader = ImageReader.newInstance(rawSize.width, rawSize.height, ImageFormat.RAW_SENSOR, burstFrames).also { reader ->
                reader.setOnImageAvailableListener({ r ->
                    try {
                        val img = r.acquireNextImage() ?: return@setOnImageAvailableListener
                        synchronized(lock) { images[img.timestamp] = img }
                        maybeHandOff()
                    } catch (_: IllegalStateException) { /* reader closed or over-acquired */ }
                }, h)
            }
            val st = texture.surfaceTexture ?: return
            st.setDefaultBufferSize(previewSize.width, previewSize.height)
            previewSurface = Surface(st)
            status.text = "OPENING RAW SENSOR…"
            opening = true
            cameraManager.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) { opening = false; cameraDevice = camera; createSession() }
                override fun onDisconnected(camera: CameraDevice) { opening = false; camera.close(); cameraDevice = null; runOnUiThread { status.text = "CAMERA DISCONNECTED" } }
                override fun onError(camera: CameraDevice, error: Int) {
                    opening = false; camera.close(); cameraDevice = null
                    runOnUiThread { status.text = "CAMERA ERROR $error"; capture.isEnabled = false }
                }
            }, h)
        } catch (e: SecurityException) {
            status.text = "CAMERA PERMISSION REQUIRED"
        } catch (e: Exception) {
            opening = false
            status.text = "RAW INIT ERROR"; toast("Не удалось открыть RAW: ${e.localizedMessage}")
        }
    }

    private fun createSession() {
        val device = cameraDevice ?: return
        val preview = previewSurface ?: return
        val readerSurface = imageReader?.surface ?: return
        try {
            device.createCaptureSession(listOf(preview, readerSurface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(configured: CameraCaptureSession) {
                    if (cameraDevice == null) { configured.close(); return }
                    session = configured
                    try {
                        val request = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                            addTarget(preview)
                            set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                            set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                        }.build()
                        configured.setRepeatingRequest(request, null, handler)
                        runOnUiThread { status.text = "RAW READY • ${imageReader?.width}×${imageReader?.height} • burst $burstFrames" }
                    } catch (e: Exception) { runOnUiThread { toast("Preview error: ${e.localizedMessage}") } }
                }
                override fun onConfigureFailed(session: CameraCaptureSession) { runOnUiThread { status.text = "RAW SESSION FAILED"; capture.isEnabled = false } }
            }, handler)
        } catch (e: Exception) { runOnUiThread { status.text = "SESSION ERROR"; toast(e.localizedMessage ?: "Session error") } }
    }

    private fun closeCamera() {
        if (busy) abortBurst("BURST INTERRUPTED")   // no-op once frames were handed to the processor
        try { session?.stopRepeating() } catch (_: Exception) {}
        try { session?.close() } catch (_: Exception) {}
        session = null
        try { cameraDevice?.close() } catch (_: Exception) {}
        cameraDevice = null
        try { previewSurface?.release() } catch (_: Exception) {}
        previewSurface = null
        synchronized(lock) {
            val reader = imageReader
            imageReader = null
            if (imagesInProcessing) readerToClose = reader          // images still being read: close afterwards
            else {
                images.values.forEach { try { it.close() } catch (_: Exception) {} }
                images.clear(); results.clear()
                try { reader?.close() } catch (_: Exception) {}
            }
        }
        opening = false
    }

    // ---- burst capture --------------------------------------------------------------------------

    private fun captureBurst() {
        if (busy) return
        val device = cameraDevice; val sess = session; val reader = imageReader; val chars = characteristics
        if (device == null || sess == null || reader == null || chars == null) { toast("RAW-камера ещё запускается"); return }
        val n = BurstPlanner.plan(
            burstFrames, reader.width.toLong() * reader.height, CameraCapabilities.freeHeapBytes(),
            CameraCapabilities.thermalStatus(this), saveTiff
        ).coerceAtMost(burstFrames)
        if (n == 0) { toast("Недостаточно памяти или устройство перегрето"); return }
        busy = true; cancelToken = CancelToken()
        synchronized(lock) { images.clear(); results.clear(); expected = n; handedOff = false }
        capture.text = "CANCEL"; setProgress("Capturing", 0f)
        try {
            val lensShading = chars.get(CameraCharacteristics.STATISTICS_INFO_AVAILABLE_LENS_SHADING_MAP_MODES)
                ?.any { it.toInt() == CameraCharacteristics.STATISTICS_LENS_SHADING_MAP_MODE_ON } == true
            val requests = List(n) {
                device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                    addTarget(reader.surface)
                    set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                    set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                    set(CaptureRequest.CONTROL_AE_LOCK, true)     // identical exposure across the burst
                    set(CaptureRequest.CONTROL_AWB_LOCK, true)
                    if (lensShading) set(CaptureRequest.STATISTICS_LENS_SHADING_MAP_MODE, CaptureRequest.STATISTICS_LENS_SHADING_MAP_MODE_ON)
                }.build()
            }
            sess.captureBurst(requests, object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, result: TotalCaptureResult) {
                    val ts = result.get(CaptureResult.SENSOR_TIMESTAMP) ?: return
                    synchronized(lock) { results[ts] = result }
                    runOnUiThread { setProgress("Capturing", synchronized(lock) { results.size } / n.toFloat()) }
                    maybeHandOff()
                }
                override fun onCaptureFailed(s: CameraCaptureSession, r: CaptureRequest, failure: CaptureFailure) {
                    synchronized(lock) { expected-- }
                    maybeHandOff()
                }
            }, handler)
            // watchdog: a burst that never completes must not leave the UI locked
            handler?.postDelayed({ if (busy && !handedOff) abortBurst("BURST TIMEOUT") }, 10_000L)
        } catch (e: Exception) {
            abortBurst("CAPTURE ERROR"); toast(e.localizedMessage ?: "RAW capture failed")
        }
    }

    private fun abortBurst(message: String) {
        synchronized(lock) {
            if (handedOff) return
            handedOff = true
            images.values.forEach { try { it.close() } catch (_: Exception) {} }
            images.clear(); results.clear()
        }
        finishUi(message)
    }

    private fun maybeHandOff() {
        val batch: List<Pair<Image, TotalCaptureResult>>
        synchronized(lock) {
            if (handedOff) return
            if (expected <= 0) { /* every frame failed */ }
            else if (images.size < expected || results.size < expected) return
            handedOff = true
            val keys = images.keys.filter { results.containsKey(it) }.sorted()
            batch = keys.map { images.remove(it)!! to results.remove(it)!! }
            images.values.forEach { try { it.close() } catch (_: Exception) {} }
            images.clear(); results.clear()
            imagesInProcessing = true
        }
        if (batch.isEmpty()) { synchronized(lock) { imagesInProcessing = false }; finishUi("RAW BURST FAILED"); return }
        val chars = characteristics ?: return
        val token = cancelToken ?: CancelToken()
        try {
            processor.execute { process(batch, chars, token) }
        } catch (e: Exception) {
            batch.forEach { try { it.first.close() } catch (_: Exception) {} }
            synchronized(lock) { imagesInProcessing = false }
            finishUi("PROCESSING UNAVAILABLE")
        }
    }

    // ---- processing (background thread, never the main thread) ----------------------------------------

    private fun process(batch: List<Pair<Image, TotalCaptureResult>>, chars: CameraCharacteristics, token: CancelToken) {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val frames = ArrayList<RawFrame>(batch.size)
        var message = "DONE"
        try {
            // 1) keep every original as DNG, copy the Bayer data, release the Image immediately
            for ((i, pair) in batch.withIndex()) {
                val (image, result) = pair
                try {
                    val w = image.width; val h = image.height
                    val plane = image.planes[0]
                    require(plane.pixelStride == 2) { "Unexpected RAW pixel stride ${plane.pixelStride}" }
                    val data = ShortArray(w * h)
                    val buf = plane.buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
                    for (y in 0 until h) { buf.position(y * plane.rowStride); buf.asShortBuffer().get(data, y * w, w) }
                    frames.add(RawFrame(w, h, data, RawMetaFactory.create(chars, result)))
                    val uri = insert("ALTE_RAW_${stamp}_F${i + 1}.dng", "image/x-adobe-dng", "Pictures/Alte Cam/RAW Burst")
                    contentResolver.openOutputStream(uri)?.use { out ->
                        DngCreator(chars, result).use { creator ->
                            creator.setOrientation(exifOrientation(chars))
                            creator.writeImage(out, image)
                        }
                    } ?: error("Cannot open DNG output")
                } finally { image.close() }
                post("Saving DNG ${i + 1}/${batch.size}", (i + 1f) / batch.size, "Capturing")
            }
        } catch (e: Exception) {
            batch.forEach { try { it.first.close() } catch (_: Exception) {} }
            message = "DNG SAVE ERROR: ${e.localizedMessage}"
        } finally {
            synchronized(lock) {
                imagesInProcessing = false
                readerToClose?.let { try { it.close() } catch (_: Exception) {} }
                readerToClose = null
            }
        }
        if (frames.isEmpty()) { finishUi(message); return }

        // 2) fuse + develop + export
        try {
            val fusion = RawFusionEngine.fuse(frames, FusionOptions(), { s, f -> post(s, f, s) }, token)
            val w = fusion.width; val h = fusion.height
            frames.clear()   // free the 16-bit copies before development
            val dev = RawDeveloper.develop(fusion.bayer, w, h, fusion.meta, DevelopOptions(want16Bit = saveTiff), { s, f -> post(s, f, s) }, token)
            post("Saving", 0f, "Saving")
            var bmp = Bitmap.createBitmap(dev.argb, w, h, Bitmap.Config.ARGB_8888)
            val rot = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
            if (rot != 0) {
                val rotated = Bitmap.createBitmap(bmp, 0, 0, w, h, Matrix().apply { postRotate(rot.toFloat()) }, true)
                if (rotated !== bmp) bmp.recycle()
                bmp = rotated
            }
            val jpeg = insert("ALTE_HDRP_$stamp.jpg", "image/jpeg", "Pictures/Alte Cam/RAW Fusion")
            contentResolver.openOutputStream(jpeg)?.use { if (!bmp.compress(Bitmap.CompressFormat.JPEG, 95, it)) error("JPEG encode failed") } ?: error("Cannot open JPEG output")
            bmp.recycle()
            if (saveTiff && dev.rgb16 != null) {
                val tif = insert("ALTE_HDRP_$stamp.tif", "image/tiff", "Pictures/Alte Cam/RAW Fusion")
                contentResolver.openOutputStream(tif)?.use { TiffWriter.writeRgb16(it.buffered(1 shl 20), w, h, dev.rgb16) } ?: error("Cannot open TIFF output")
            }
            message = "DONE • ${fusion.usedFrames.size}/${batch.size} frames merged" +
                (if (fusion.discarded.isNotEmpty()) " • discarded ${fusion.discarded.size}" else "") +
                " • ${fusion.elapsedMs} ms"
        } catch (e: CancellationException) {
            message = "CANCELLED • originals (DNG) kept"
        } catch (e: OutOfMemoryError) {
            message = "OUT OF MEMORY • originals (DNG) kept"
        } catch (e: Exception) {
            message = "FUSION FAILED • originals (DNG) kept"
            runOnUiThread { toast("RAW fusion failed: ${e.localizedMessage}") }
        }
        finishUi(message)
    }

    private fun exifOrientation(chars: CameraCharacteristics): Int = when (chars.get(CameraCharacteristics.SENSOR_ORIENTATION)) {
        90 -> ExifInterface.ORIENTATION_ROTATE_90
        180 -> ExifInterface.ORIENTATION_ROTATE_180
        270 -> ExifInterface.ORIENTATION_ROTATE_270
        else -> ExifInterface.ORIENTATION_NORMAL
    }

    private fun insert(name: String, mime: String, relativePath: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
        }
        return contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("MediaStore insert failed")
    }

    // ---- UI helpers -----------------------------------------------------------------------------------------

    private fun post(text: String, fraction: Float, stage: String) {
        runOnUiThread { setProgress(stage, fraction, text) }
    }

    private fun setProgress(stage: String, fraction: Float, text: String = stage) {
        if (isDestroyed) return
        status.text = "${text.uppercase(Locale.US)} ${(fraction * 100).toInt()}%"
        progressBar.progress = (fraction.coerceIn(0f, 1f) * 1000).toInt()
    }

    private fun finishUi(message: String) {
        busy = false
        runOnUiThread {
            if (isDestroyed) return@runOnUiThread
            capture.isEnabled = true; capture.text = "CAPTURE"
            progressBar.progress = 0
            status.text = message
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
