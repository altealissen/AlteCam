package com.altecam.engine

import java.util.concurrent.Callable
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * HDR+-style multi-frame RAW merge (own implementation of the published ideas):
 *  1. normalise every frame (black level, exposure ratio),
 *  2. choose the sharpest frame as reference, reject blurred / unalignable frames,
 *  3. align each alternate frame to the reference per tile (pyramid block matching, sub-pixel),
 *  4. merge in the Bayer domain with a noise-model-aware robust weight:
 *     w = 1 / (1 + excess/k), excess = max(0, localMeanDiff^2 / sigma_pair^2 - 1).
 *     Pure noise gives w ~ 1 (average), real mismatch (motion, misalignment) gives w -> 0.
 * Spatial-domain merge (not the frequency-domain Wiener filter of the paper).
 */
object RawFusionEngine {

    private const val SATURATION = 0.985f

    fun fuse(
        input: List<RawFrame>,
        options: FusionOptions = FusionOptions(),
        progress: ProgressListener? = null,
        cancel: CancelToken? = null
    ): FusionResult {
        val t0 = System.nanoTime()
        require(input.isNotEmpty()) { "No frames" }
        val frames = input.take(options.maxFrames)
        val w = frames[0].width; val h = frames[0].height
        require(w >= 64 && h >= 64) { "Frame too small" }
        require(frames.all { it.width == w && it.height == h }) { "RAW frame dimensions differ" }
        require(frames.all { it.meta.cfa == frames[0].meta.cfa }) { "CFA pattern differs between frames" }

        // ---- reference selection ------------------------------------------------
        progress?.onProgress("Aligning", 0f)
        val sortedProducts = frames.map { it.meta.exposureProduct }.sorted()
        val medianProduct = sortedProducts[sortedProducts.size / 2]
        val tile = options.tileSize
        val planes0 = frames.map { f ->
            FrameAlignmentEngine.binHalf(f, (medianProduct / f.meta.exposureProduct).toFloat())
        }
        val pyramids = planes0.map { FrameAlignmentEngine.buildPyramid(it, tile) }
        val sharp = FloatArray(frames.size) { i ->
            val lv = pyramids[i][min(2, pyramids[i].size - 1)]
            FrameAlignmentEngine.sharpness(lv)
        }
        val eligible = frames.indices.filter {
            val r = frames[it].meta.exposureProduct / medianProduct
            r in 0.95..1.05
        }.ifEmpty { frames.indices.toList() }
        val refIdx = eligible.maxByOrNull { sharp[it] }!!
        val ref = frames[refIdx]
        val refMeta = ref.meta

        val discarded = LinkedHashMap<Int, String>()
        val alts = ArrayList<Int>()
        for (i in frames.indices) {
            if (i == refIdx) continue
            val sameExposure = frames[i].meta.exposureProduct / refMeta.exposureProduct in 0.95..1.05
            if (sameExposure && sharp[i] < options.sharpnessRejectRatio * sharp[refIdx]) {
                discarded[i] = "motion blur (sharpness %.0f%% of reference)".format(100f * sharp[i] / sharp[refIdx])
            } else alts.add(i)
        }

        // ---- alignment ----------------------------------------------------------
        val fields = HashMap<Int, AlignmentField>()
        for ((n, i) in alts.withIndex()) {
            cancel?.throwIfCancelled()
            fields[i] = FrameAlignmentEngine.align(pyramids[refIdx], pyramids[i], tile, options.subpixel, cancel)
            progress?.onProgress("Aligning", (n + 1f) / max(1, alts.size))
        }
        if (fields.size >= 2) {
            val costs = fields.mapValues { it.value.medianCost() }
            val minCost = costs.values.min()
            for ((i, c) in costs) {
                // guard against zero (perfect synthetic match) with a small absolute floor
                if (c > options.alignmentRejectRatio * max(minCost, 1e-4f) && c > 0.01f) {
                    discarded[i] = "alignment failed (error %.4f vs best %.4f)".format(c, minCost)
                }
            }
            alts.removeAll(discarded.keys)
        }

        // ---- merge --------------------------------------------------------------
        val out = FloatArray(w * h)
        val ctxs = alts.map { MergeInput(frames[it], fields[it]!!, (refMeta.exposureProduct / frames[it].meta.exposureProduct).toFloat(), options.subpixel) }
        val refCtx = MergeInput(ref, null, 1f, false)
        val fallbackVar = if (refMeta.noiseS == null || refMeta.noiseO == null) estimateFallbackVariance(refCtx, ctxs) else null

        val bands = options.threads * 4
        val rowsPerBand = (h + bands - 1) / bands
        val weightAcc = DoubleArray(bands)
        val countAcc = LongArray(bands)
        val done = java.util.concurrent.atomic.AtomicInteger(0)
        progress?.onProgress("Merging", 0f)
        val pool = Executors.newFixedThreadPool(options.threads)
        try {
            val futures = (0 until bands).map { b ->
                pool.submit(Callable {
                    val y0 = b * rowsPerBand
                    val y1 = min(h, y0 + rowsPerBand)
                    if (y0 < y1) {
                        val acc = mergeBand(refCtx, ctxs, refMeta, fallbackVar, options.mergeTolerance, out, y0, y1, cancel)
                        weightAcc[b] = acc.first; countAcc[b] = acc.second
                    }
                    progress?.onProgress("Merging", done.incrementAndGet().toFloat() / bands)
                })
            }
            futures.forEach { it.get() }
        } catch (e: java.util.concurrent.ExecutionException) {
            throw (e.cause ?: e)
        } finally {
            pool.shutdownNow()
        }
        val totalCount = countAcc.sum()
        val meanW = if (totalCount == 0L) 0f else (weightAcc.sum() / totalCount).toFloat()
        return FusionResult(
            w, h, out, refMeta, refIdx, listOf(refIdx) + alts, discarded,
            (System.nanoTime() - t0) / 1_000_000, meanW
        )
    }

    /** A frame prepared for sampling in the reference's normalised domain. */
    private class MergeInput(val frame: RawFrame, val field: AlignmentField?, val gain: Float, val subpixel: Boolean) {
        val w = frame.width
        val h = frame.height
        val black = frame.meta.blackLevel
        val scale = FloatArray(4) { gain / (frame.meta.whiteLevel - frame.meta.blackLevel[it]) }
        val satRaw = FloatArray(4) { frame.meta.blackLevel[it] + SATURATION * (frame.meta.whiteLevel - frame.meta.blackLevel[it]) }

        fun norm(x: Int, y: Int): Float {
            val p = ((y and 1) shl 1) or (x and 1)
            return ((frame.data[y * w + x].toInt() and 0xFFFF) - black[p]) * scale[p]
        }

        fun isSat(x: Int, y: Int): Boolean {
            val p = ((y and 1) shl 1) or (x and 1)
            return (frame.data[y * w + x].toInt() and 0xFFFF) >= satRaw[p]
        }

        /** Fills [dst] with row y sampled at motion-compensated positions; NaN where unavailable. */
        fun sampleRow(y: Int, dst: FloatArray) {
            val f = field
            if (f == null) {
                for (x in 0 until w) dst[x] = norm(x, y)
                return
            }
            val t = f.tile
            val tyIdx = min((y shr 1) / t, f.tilesY - 1)
            for (x in 0 until w) {
                val k = tyIdx * f.tilesX + min((x shr 1) / t, f.tilesX - 1)
                var vx = f.vx[k]; var vy = f.vy[k]
                if (!subpixel) { vx = Math.round(vx).toFloat(); vy = Math.round(vy).toFloat() }
                val fx0 = FrameAlignmentEngine.ifloor(vx); val fy0 = FrameAlignmentEngine.ifloor(vy)
                val ax = vx - fx0; val ay = vy - fy0
                val bx = x + 2 * fx0; val by = y + 2 * fy0
                val needX1 = ax > 1e-4f; val needY1 = ay > 1e-4f
                if (bx < 0 || by < 0 || bx + (if (needX1) 2 else 0) >= w || by + (if (needY1) 2 else 0) >= h) {
                    dst[x] = Float.NaN; continue
                }
                val bx1 = if (needX1) bx + 2 else bx; val by1 = if (needY1) by + 2 else by
                if (isSat(bx, by) || isSat(bx1, by) || isSat(bx, by1) || isSat(bx1, by1)) { dst[x] = Float.NaN; continue }
                val v00 = norm(bx, by); val v10 = norm(bx1, by)
                val v01 = norm(bx, by1); val v11 = norm(bx1, by1)
                val top = v00 + (v10 - v00) * ax
                val bot = v01 + (v11 - v01) * ax
                dst[x] = top + (bot - top) * ay
            }
        }
    }

    /** Ring of recent rows (aligned samples and squared differences) for one alternate frame. */
    private class RowCache(val w: Int) {
        val size = 6
        val tags = IntArray(size) { Int.MIN_VALUE }
        val al = Array(size) { FloatArray(w) }
        val d2 = Array(size) { FloatArray(w) }
    }

    private fun mergeBand(
        refCtx: MergeInput, alts: List<MergeInput>, meta: RawMeta, fallbackVar: Float?,
        tol: Float, out: FloatArray, y0: Int, y1: Int, cancel: CancelToken?
    ): Pair<Double, Long> {
        val w = refCtx.w; val h = refCtx.h
        val refRows = Array(6) { FloatArray(w) }
        val refTags = IntArray(6) { Int.MIN_VALUE }
        val caches = alts.map { RowCache(w) }
        val num = FloatArray(w); val den = FloatArray(w)
        val S = meta.noiseS; val O = meta.noiseO
        var wSum = 0.0; var wCount = 0L
        val invTol = 1f / tol

        fun refRow(y: Int): FloatArray {
            val s = ((y % 6) + 6) % 6
            if (refTags[s] != y) { refCtx.sampleRow(y, refRows[s]); refTags[s] = y }
            return refRows[s]
        }

        fun ensure(ai: Int, y: Int): Int {
            val c = caches[ai]
            val s = ((y % 6) + 6) % 6
            if (c.tags[s] != y) {
                alts[ai].sampleRow(y, c.al[s])
                val r = refRow(y)
                val a = c.al[s]; val d = c.d2[s]
                for (x in 0 until w) { val df = a[x] - r[x]; d[x] = df * df } // NaN propagates
                c.tags[s] = y
            }
            return s
        }

        for (y in y0 until y1) {
            if ((y and 15) == 0) cancel?.throwIfCancelled()
            val r = refRow(y)
            java.util.Arrays.fill(num, 0f); java.util.Arrays.fill(den, 0f)
            for (ai in alts.indices) {
                val gain = alts[ai].gain
                val s0 = ensure(ai, y)
                val a = caches[ai].al[s0]
                val rowsAvail = intArrayOf(y, y - 2, y + 2).filter { it in 0 until h }
                val slots = rowsAvail.map { ensure(ai, it) }
                for (x in 0 until w) {
                    val av = a[x]
                    if (av != av) continue
                    // local mean of squared difference over the 3x3 same-colour neighbourhood
                    var sum = 0f; var cnt = 0
                    for (s in slots) {
                        val d = caches[ai].d2[s]
                        val xl = x - 2; val xr = x + 2
                        val c0 = d[x]; if (c0 == c0) { sum += c0; cnt++ }
                        if (xl >= 0) { val v = d[xl]; if (v == v) { sum += v; cnt++ } }
                        if (xr < w) { val v = d[xr]; if (v == v) { sum += v; cnt++ } }
                    }
                    if (cnt == 0) continue
                    val meanD2 = sum / cnt
                    val sig2: Float = if (fallbackVar != null) fallbackVar else {
                        val p = ((y and 1) shl 1) or (x and 1)
                        val v = max(0f, 0.5f * (r[x] + av))
                        val refVar = S!![p] * v + O!![p]
                        val altVar = gain * S[p] * v + gain * gain * O[p]
                        refVar + altVar
                    }
                    val excess = max(0f, meanD2 / max(sig2, 1e-12f) - 1f)
                    val wgt = 1f / (1f + excess * invTol)
                    num[x] += wgt * av; den[x] += wgt
                    wSum += wgt; wCount++
                }
            }
            val base = y * w
            for (x in 0 until w) out[base + x] = (r[x] + num[x]) / (1f + den[x])
        }
        // wSum/wCount are per (alt,pixel); report mean weight over alt samples
        return Pair(wSum, wCount)
    }

    /**
     * When the device gives no noise profile: estimate the variance of (alt - ref) from
     * the median of squared differences (median of chi^2_1 = 0.4549 sigma^2), which is
     * robust against moving objects covering less than half of the frame.
     */
    private fun estimateFallbackVariance(ref: MergeInput, alts: List<MergeInput>): Float {
        if (alts.isEmpty()) return 1e-6f
        val samples = ArrayList<Float>()
        val rrow = FloatArray(ref.w); val arow = FloatArray(ref.w)
        for (a in alts) {
            var y = 8
            while (y < ref.h - 8) {
                ref.sampleRow(y, rrow); a.sampleRow(y, arow)
                var x = 8
                while (x < ref.w - 8) {
                    val v = arow[x]
                    if (v == v) { val d = v - rrow[x]; samples.add(d * d) }
                    x += 5
                }
                y += 9
            }
        }
        if (samples.isEmpty()) return 1e-6f
        samples.sort()
        return max(1e-9f, samples[samples.size / 2] / 0.4549f)
    }
}
