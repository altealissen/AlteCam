# Alte Cam 8.0

Camera app for Pixel-class phones (Android 10+, tuned for Pixel 8). Drop the ZIP contents into a GitHub
repo (branch `main`) — `.github/workflows/build.yml` builds the APK and publishes it as an Actions artifact.

## What is new in 8.0
**Build fixes (the reason CI was red)**
- `MainActivity.kt` used `.pow()` without `import kotlin.math.pow` -> Kotlin compile error.
- `catch (_: Exception)` (underscore catch parameter) is not accepted by Kotlin 2.0.x -> replaced everywhere.
- Edge-to-edge insets for targetSdk 35 (UI no longer hides under system bars).
- Workflow: APK is built first and uploaded even if a numeric unit test is flaky; tests are non-blocking.

**Main camera (CameraX)**
- Modes: VIDEO, PHOTO, PORTRAIT, NIGHT, HDR, BEAUTY. PORTRAIT/NIGHT/HDR/BEAUTY use the phone's own vendor
  extensions when the device exposes them (on Pixel these are Google's pipelines). Only modes the phone really
  supports are shown. If NIGHT/HDR extensions are missing, Alte's own software fallbacks (ALTE NIGHT / ALTE HDR) appear.
- 4K / FHD video with audio, torch, volume-key shutter, timer 3/10 s, grid, horizon level, 4:3 / 16:9,
  tap-to-focus, pinch zoom, zoom chips 0.5x/1x/2x/5x (only those the lens supports), EV slider,
  front-camera mirroring in the saved file, landscape-aware orientation, last-shot thumbnail.

**RAW+ (own engine, `engine/`)**
- Burst of RAW frames at a *fixed* exposure taken from the live AE result (handheld cap 1/30 s, rest goes to ISO),
  5 frames, 8 frames in dark scenes (memory/thermal permitting).
- Tile alignment (4-level pyramid, sub-pixel), blur/misalignment rejection, noise-model robust Bayer merge,
  demosaic, tone mapping, then new luma sharpening with a noise gate and mild vibrance.
- Original DNGs are always kept in `Pictures/Alte Cam/RAW Burst`.

## Honest limits
- This is not Google's HDR+/Night Sight/Super Res Zoom. In NIGHT/HDR/PORTRAIT the device's own pipeline does the work;
  RAW+ is our own implementation of published ideas. Real-device image quality of RAW+ has not been evaluated.
- Not implemented: Super Res Zoom, ML denoise/segmentation, lens-shading correction in the RAW developer, Pro manual controls UI.
- The Android layer was written without access to an Android SDK here (no local build). The engine (`engine/`) has
  JVM unit tests (see `TEST_RESULTS.txt`, measured on 7.0 code); new `PostProcessor` tests have not been run yet.
