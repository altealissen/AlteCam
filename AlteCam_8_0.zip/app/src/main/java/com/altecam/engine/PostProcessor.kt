package com.altecam.engine

import kotlin.math.abs

/**
 * Cheap post filters on the developed 8-bit ARGB image (platform independent, unit-testable).
 * Streaming: keeps only three rows of luma, so memory overhead is ~12 bytes per image column.
 */
object PostProcessor {

    /**
     * Luma unsharp mask with a noise gate: differences smaller than [noiseGate] (in 0..255 luma
     * units) are attenuated smoothly, so flat noisy areas are not amplified while real edges are.
     * Modifies [argb] in place. Border pixels are left untouched.
     */
    fun sharpen(argb: IntArray, w: Int, h: Int, amount: Float = 0.5f, noiseGate: Float = 3f) {
        if (w < 3 || h < 3 || amount <= 0f) return
        require(argb.size >= w * h)
        val rows = Array(3) { FloatArray(w) }

        fun fillRow(y: Int) {
            val r = rows[y % 3]
            val base = y * w
            for (x in 0 until w) {
                val p = argb[base + x]
                r[x] = 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
            }
        }

        fillRow(0); fillRow(1)
        for (y in 1 until h - 1) {
            fillRow(y + 1)
            val a = rows[(y - 1) % 3]; val b = rows[y % 3]; val c = rows[(y + 1) % 3]
            val base = y * w
            for (x in 1 until w - 1) {
                val blur = (a[x - 1] + a[x] + a[x + 1] + b[x - 1] + b[x] + b[x + 1] + c[x - 1] + c[x] + c[x + 1]) / 9f
                var d = b[x] - blur
                val ad = abs(d)
                if (ad < noiseGate) d *= ad / noiseGate
                val delta = d * amount
                if (delta == 0f) continue
                val p = argb[base + x]
                val r = clamp255(((p shr 16) and 255) + delta)
                val g = clamp255(((p shr 8) and 255) + delta)
                val bl = clamp255((p and 255) + delta)
                argb[base + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
            }
        }
    }

    /** Mild vibrance: boosts low-saturation colours more than saturated ones. In place. */
    fun vibrance(argb: IntArray, w: Int, h: Int, amount: Float = 0.12f) {
        if (amount <= 0f) return
        for (i in 0 until w * h) {
            val p = argb[i]
            val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            val mx = maxOf(r, g, b); val mn = minOf(r, g, b)
            if (mx == 0) continue
            val sat = (mx - mn) / mx.toFloat()
            val k = 1f + amount * (1f - sat)
            val lum = 0.299f * r + 0.587f * g + 0.114f * b
            argb[i] = (0xFF shl 24) or (clamp255(lum + (r - lum) * k) shl 16) or
                (clamp255(lum + (g - lum) * k) shl 8) or clamp255(lum + (b - lum) * k)
        }
    }

    private fun clamp255(v: Float): Int = if (v < 0f) 0 else if (v > 255f) 255 else (v + 0.5f).toInt()
}
