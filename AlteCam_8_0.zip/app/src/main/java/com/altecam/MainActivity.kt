package com.altecam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.MediaActionSound
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.ZoomState
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.LiveData
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Capture modes. NIGHT / HDR / PORTRAIT / BEAUTY use the phone's own vendor extensions
 * (on a Pixel these are Google's own multi-frame pipelines) when the device exposes them.
 * STACK_* are Alte's own software fallbacks, offered only when the extension is missing.
 */
private enum class Mode(val label: String) {
    VIDEO("VIDEO"), PHOTO("PHOTO"), PORTRAIT("PORTRAIT"), NIGHT("NIGHT"), HDR("HDR"), BEAUTY("BEAUTY"),
    STACK_NIGHT("ALTE NIGHT"), STACK_HDR("ALTE HDR")
}

private val ACCENT: Int = 0xFFFFD60A.toInt()

class MainActivity : AppCompatActivity() {
    // ---- views ----
    private lateinit var previewView: PreviewView
    private lateinit var previewBox: FrameLayout
    private lateinit var overlay: OverlayView
    private lateinit var statusView: TextView
    private lateinit var countdownView: TextView
    private lateinit var focusRing: View
    private lateinit var zoomRow: LinearLayout
    private lateinit var modeRow: LinearLayout
    private lateinit var shutter: FrameLayout
    private lateinit var shutterInner: View
    private lateinit var thumb: ImageView
    private lateinit var evPanel: LinearLayout
    private lateinit var evLabel: TextView
    private lateinit var evBar: SeekBar
    private lateinit var flashBtn: TextView
    private lateinit var gridBtn: TextView
    private lateinit var timerBtn: TextView
    private lateinit var ratioBtn: TextView
    private lateinit var evBtn: TextView

    // ---- state ----
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val sound = MediaActionSound()
    private var provider: ProcessCameraProvider? = null
    private var extMgr: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var zoomLive: LiveData<ZoomState>? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var mode = Mode.PHOTO
    private var modes: List<Mode> = listOf(Mode.VIDEO, Mode.PHOTO)
    private var flashMode = ImageCapture.FLASH_MODE_OFF
    private var timerSec = 0
    private var ratio169 = false
    private var videoUhd = true
    private var exposureIndex = 0
    private var lastUri: Uri? = null
    private var lastIsVideo = false
    private var countingDown = false
    private var pinched = false
    @Volatile private var busy = false

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        if (hasCamera()) startCamera() else toast("Для работы Alte Cam нужен доступ к камере")
    }

    private val scaleDetector by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                pinched = true
                val z = camera?.cameraInfo?.zoomState?.value ?: return true
                val r = (z.zoomRatio * detector.scaleFactor).coerceIn(z.minZoomRatio, z.maxZoomRatio)
                camera?.cameraControl?.setZoomRatio(r)
                return true
            }
        })
    }

    private val sensorManager by lazy { getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            val ax = event.values[0]; val ay = event.values[1]; val az = event.values[2]
            val roll = Math.toDegrees(atan2(-ax.toDouble(), ay.toDouble())).toFloat()
            val upright = abs(az) < 7.5f && abs(roll) < 45f
            overlay.setLevel(roll, upright)
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    private val orientationListener by lazy {
        object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                val r = when {
                    orientation >= 315 || orientation < 45 -> Surface.ROTATION_0
                    orientation < 135 -> Surface.ROTATION_270
                    orientation < 225 -> Surface.ROTATION_180
                    else -> Surface.ROTATION_90
                }
                imageCapture?.targetRotation = r
                videoCapture?.targetRotation = r
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val need = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) startCamera() else permissionLauncher.launch(need.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        val acc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (acc != null) sensorManager.registerListener(sensorListener, acc, SensorManager.SENSOR_DELAY_UI)
        if (orientationListener.canDetectOrientation()) orientationListener.enable()
    }

    override fun onPause() {
        sensorManager.unregisterListener(sensorListener)
        orientationListener.disable()
        main.removeCallbacksAndMessages(null)
        countingDown = false
        super.onPause()
    }

    override fun onDestroy() {
        recording?.stop()
        recording = null
        sound.release()
        executor.shutdown()
        super.onDestroy()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event?.repeatCount == 0) onShutter()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun hasCamera() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------------------------------------------
    // UI
    // ------------------------------------------------------------------------------------------

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(column, FrameLayout.LayoutParams(-1, -1))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        // ---- top bar ----
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(2), dp(6), dp(2))
        }
        flashBtn = label("FLASH OFF", 11f).also { it.setOnClickListener { cycleFlash() } }
        gridBtn = label("GRID", 11f).also { it.setOnClickListener { toggleGrid() } }
        timerBtn = label("TIMER OFF", 11f).also { it.setOnClickListener { cycleTimer() } }
        ratioBtn = label("4:3", 11f).also { it.setOnClickListener { toggleRatio() } }
        evBtn = label("EV", 11f).also { it.setOnClickListener { toggleEvPanel() } }
        val rawBtn = label("RAW+", 11f, ACCENT).also {
            it.setOnClickListener { startActivity(Intent(this, RawCaptureActivity::class.java)) }
        }
        for (b in listOf(flashBtn, gridBtn, timerBtn, ratioBtn, evBtn, rawBtn)) top.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f))
        column.addView(top, LinearLayout.LayoutParams(-1, -2))

        // ---- preview box ----
        previewBox = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        previewBox.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        overlay = OverlayView(this)
        previewBox.addView(overlay, FrameLayout.LayoutParams(-1, -1))

        statusView = label("", 11f, ACCENT).apply {
            background = rounded(0x88000000.toInt(), 10)
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        previewBox.addView(statusView, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(10), dp(10), 0, 0) })

        zoomRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        previewBox.addView(zoomRow, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(12) })

        countdownView = label("", 96f).apply { visibility = View.GONE }
        previewBox.addView(countdownView, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        focusRing = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(2), ACCENT) }
            visibility = View.GONE
        }
        previewBox.addView(focusRing, FrameLayout.LayoutParams(dp(72), dp(72)))

        previewView.setOnTouchListener { v, ev ->
            scaleDetector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) pinched = false
            if (ev.actionMasked == MotionEvent.ACTION_UP && !pinched && ev.eventTime - ev.downTime < 400) {
                v.performClick()
                focusAt(ev.x, ev.y)
            }
            true
        }
        column.addView(previewBox, LinearLayout.LayoutParams(-1, previewHeight(4f / 3f)))

        // ---- bottom panel ----
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        column.addView(bottom, LinearLayout.LayoutParams(-1, 0, 1f))

        evPanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0); visibility = View.GONE
        }
        evLabel = label("0.0 EV", 12f)
        evBar = SeekBar(this).apply {
            max = 12; progress = 6
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val cam = camera ?: return
                    val r = cam.cameraInfo.exposureState.exposureCompensationRange
                    exposureIndex = r.lower + progress
                    cam.cameraControl.setExposureCompensationIndex(exposureIndex)
                    updateEvLabel()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        evPanel.addView(evLabel, LinearLayout.LayoutParams(dp(80), -2))
        evPanel.addView(evBar, LinearLayout.LayoutParams(0, dp(36), 1f))
        bottom.addView(evPanel, LinearLayout.LayoutParams(-1, -2))

        modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(modeRow, FrameLayout.LayoutParams(-2, dp(40)))
        }
        bottom.addView(scroller, LinearLayout.LayoutParams(-1, dp(44)))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(0xFF2A2A2E.toInt(), 14)
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
            setOnClickListener { openLast() }
        }
        shutter = FrameLayout(this).apply {
            background = circle(Color.TRANSPARENT, Color.WHITE, dp(4))
            setOnClickListener { onShutter() }
        }
        shutterInner = View(this).apply { background = circle(Color.WHITE, 0, 0) }
        shutter.addView(shutterInner, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER))
        val flip = label("⟲", 26f).apply {
            background = circle(0x66FFFFFF, 0, 0)
            setOnClickListener { flipCamera() }
        }
        row.addView(thumb, LinearLayout.LayoutParams(dp(52), dp(52)).apply { setMargins(dp(24), 0, dp(24), 0) })
        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(shutter, LinearLayout.LayoutParams(dp(78), dp(78)))
        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(flip, LinearLayout.LayoutParams(dp(52), dp(52)).apply { setMargins(dp(24), 0, dp(24), 0) })
        bottom.addView(row, LinearLayout.LayoutParams(-1, dp(92)))

        setContentView(root)
    }

    private fun label(text: String, size: Float = 12f, color: Int = Color.WHITE): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun circle(fill: Int, stroke: Int, strokeWidth: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(fill)
        if (strokeWidth > 0) setStroke(strokeWidth, stroke)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun previewHeight(ratio: Float): Int {
        val sw = resources.displayMetrics.widthPixels
        val avail = resources.displayMetrics.heightPixels - dp(52 + 190)
        return min((sw * ratio).toInt(), avail)
    }

    private fun useRatio169() = mode == Mode.VIDEO || ratio169

    private fun applyRatioUi() {
        val r = if (useRatio169()) 16f / 9f else 4f / 3f
        previewBox.layoutParams = LinearLayout.LayoutParams(-1, previewHeight(r))
        ratioBtn.text = if (mode == Mode.VIDEO) (if (videoUhd) "4K" else "FHD") else (if (ratio169) "16:9" else "4:3")
    }

    private fun updateTopButtons() {
        flashBtn.text = when (flashMode) {
            ImageCapture.FLASH_MODE_AUTO -> "FLASH AUTO"
            ImageCapture.FLASH_MODE_ON -> if (mode == Mode.VIDEO) "TORCH ON" else "FLASH ON"
            else -> if (mode == Mode.VIDEO) "TORCH OFF" else "FLASH OFF"
        }
        flashBtn.setTextColor(if (flashMode == ImageCapture.FLASH_MODE_OFF) Color.WHITE else ACCENT)
        timerBtn.text = if (timerSec == 0) "TIMER OFF" else "TIMER ${timerSec}s"
        timerBtn.setTextColor(if (timerSec == 0) Color.WHITE else ACCENT)
        gridBtn.setTextColor(if (overlay.showGrid) ACCENT else Color.WHITE)
        evBtn.setTextColor(if (evPanel.visibility == View.VISIBLE) ACCENT else Color.WHITE)
    }

    private fun setStatus(text: String) {
        runOnUiThread { statusView.text = text; statusView.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun cycleFlash() {
        if (camera?.cameraInfo?.hasFlashUnit() == false) { toast("На этой камере нет вспышки"); return }
        flashMode = when (flashMode) {
            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
            ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        applyFlash(); updateTopButtons()
    }

    private fun applyFlash() {
        if (mode == Mode.VIDEO) camera?.cameraControl?.enableTorch(flashMode == ImageCapture.FLASH_MODE_ON)
        else {
            camera?.cameraControl?.enableTorch(false)
            imageCapture?.flashMode = flashMode
        }
    }

    private fun toggleGrid() { overlay.showGrid = !overlay.showGrid; updateTopButtons() }

    private fun cycleTimer() { timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }; updateTopButtons() }

    private fun toggleRatio() {
        if (recording != null) return
        if (mode == Mode.VIDEO) videoUhd = !videoUhd else ratio169 = !ratio169
        bind()
    }

    private fun toggleEvPanel() {
        evPanel.visibility = if (evPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        updateTopButtons()
    }

    private fun updateEvLabel() {
        val step = camera?.cameraInfo?.exposureState?.exposureCompensationStep?.toFloat() ?: 0.333f
        evLabel.text = "%+.1f EV".format(Locale.US, exposureIndex * step)
    }

    private fun flipCamera() {
        if (recording != null) return
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        bind()
    }

    private fun rebuildModeRow() {
        modeRow.removeAllViews()
        for (m in modes) {
            val t = label(m.label, 13f, if (m == mode) ACCENT else Color.WHITE)
            t.setPadding(dp(14), 0, dp(14), 0)
            t.setOnClickListener { if (recording == null && m != mode) { mode = m; bind() } }
            modeRow.addView(t, LinearLayout.LayoutParams(-2, dp(40)))
        }
    }

    private fun fmtZoom(v: Float): String =
        if (abs(v - v.roundToInt()) < 0.05f) "${v.roundToInt()}×" else "%.1f×".format(Locale.US, v)

    private fun updateZoomUi(z: ZoomState) {
        zoomRow.removeAllViews()
        val presets = listOf(0.5f, 1f, 2f, 5f).filter { it >= z.minZoomRatio - 0.01f && it <= z.maxZoomRatio + 0.01f }
        val cur = z.zoomRatio
        var active = 0
        presets.forEachIndexed { i, p -> if (cur >= p - 0.05f) active = i }
        presets.forEachIndexed { i, p ->
            val isActive = i == active
            val t = label(if (isActive) fmtZoom(cur) else fmtZoom(p).removeSuffix("×"), if (isActive) 13f else 12f, if (isActive) ACCENT else Color.WHITE)
            t.background = circle(0x88000000.toInt(), 0, 0)
            t.setOnClickListener { camera?.cameraControl?.setZoomRatio(p) }
            val s = if (isActive) dp(44) else dp(38)
            zoomRow.addView(t, LinearLayout.LayoutParams(s, s).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
    }

    private fun setRecordingUi(on: Boolean) {
        shutterInner.background = if (on) rounded(0xFFFF3B30.toInt(), 8) else circle(if (mode == Mode.VIDEO) 0xFFFF3B30.toInt() else Color.WHITE, 0, 0)
        val size = if (on) dp(30) else dp(60)
        shutterInner.layoutParams = FrameLayout.LayoutParams(size, size, Gravity.CENTER)
        modeRow.alpha = if (on) 0.3f else 1f
    }

    private fun describeMode(): String = when (mode) {
        Mode.VIDEO -> "VIDEO • ${if (videoUhd) "4K" else "FHD"}"
        Mode.PHOTO -> "PHOTO"
        Mode.PORTRAIT -> "PORTRAIT • device extension"
        Mode.NIGHT -> "NIGHT • device extension"
        Mode.HDR -> "HDR • device extension"
        Mode.BEAUTY -> "FACE RETOUCH • device extension"
        Mode.STACK_NIGHT -> "ALTE NIGHT • 4-frame stack"
        Mode.STACK_HDR -> "ALTE HDR • 3-frame bracket"
    }

    // ------------------------------------------------------------------------------------------
    // camera binding
    // ------------------------------------------------------------------------------------------

    private fun startCamera() {
        val p = provider
        if (p != null) { bind(); return }
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val prov = future.get()
                provider = prov
                val ef = ExtensionsManager.getInstanceAsync(this, prov)
                ef.addListener({
                    extMgr = try { ef.get() } catch (e: Exception) { null }
                    bind()
                }, ContextCompat.getMainExecutor(this))
            } catch (e: Exception) {
                toast("Ошибка запуска камеры: ${e.localizedMessage}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun extOf(m: Mode): Int? = when (m) {
        Mode.PORTRAIT -> ExtensionMode.BOKEH
        Mode.NIGHT -> ExtensionMode.NIGHT
        Mode.HDR -> ExtensionMode.HDR
        Mode.BEAUTY -> ExtensionMode.FACE_RETOUCH
        else -> null
    }

    private fun computeModes(base: CameraSelector): List<Mode> {
        val mgr = extMgr
        fun ok(em: Int): Boolean = try { mgr != null && mgr.isExtensionAvailable(base, em) } catch (e: Exception) { false }
        val list = ArrayList<Mode>()
        list.add(Mode.VIDEO); list.add(Mode.PHOTO)
        if (ok(ExtensionMode.BOKEH)) list.add(Mode.PORTRAIT)
        list.add(if (ok(ExtensionMode.NIGHT)) Mode.NIGHT else Mode.STACK_NIGHT)
        list.add(if (ok(ExtensionMode.HDR)) Mode.HDR else Mode.STACK_HDR)
        if (ok(ExtensionMode.FACE_RETOUCH)) list.add(Mode.BEAUTY)
        return list
    }

    private fun videoQuality(): QualitySelector {
        val order = if (videoUhd) listOf(Quality.UHD, Quality.FHD, Quality.HD, Quality.SD) else listOf(Quality.FHD, Quality.HD, Quality.SD)
        return QualitySelector.fromOrderedList(order, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
    }

    private fun bind() {
        val p = provider ?: return
        if (recording != null) return
        val base = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        modes = computeModes(base)
        if (mode !in modes) mode = Mode.PHOTO
        rebuildModeRow()
        applyRatioUi()
        setRecordingUi(false)

        var selector = base
        val em = extOf(mode)
        val mgr = extMgr
        if (em != null && mgr != null) selector = mgr.getExtensionEnabledCameraSelector(base, em)

        val rs = ResolutionSelector.Builder()
            .setAspectRatioStrategy(
                if (useRatio169()) AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
                else AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
            ).build()
        val preview = Preview.Builder().setResolutionSelector(rs).build()
        preview.setSurfaceProvider(previewView.surfaceProvider)

        try {
            p.unbindAll()
            if (mode == Mode.VIDEO) {
                val recorder = Recorder.Builder().setQualitySelector(videoQuality()).build()
                val vc = VideoCapture.withOutput(recorder)
                camera = p.bindToLifecycle(this, selector, preview, vc)
                videoCapture = vc; imageCapture = null
            } else {
                val ic = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(97)
                    .setResolutionSelector(rs)
                    .setFlashMode(flashMode)
                    .build()
                camera = p.bindToLifecycle(this, selector, preview, ic)
                imageCapture = ic; videoCapture = null
            }
            onBound()
        } catch (e: Exception) {
            if (mode != Mode.PHOTO) {
                toast("Режим ${mode.label} недоступен: ${e.localizedMessage}")
                mode = Mode.PHOTO
                bind()
            } else toast("Ошибка запуска камеры: ${e.localizedMessage}")
        }
    }

    private fun onBound() {
        val cam = camera ?: return
        zoomLive?.removeObservers(this)
        zoomLive = cam.cameraInfo.zoomState
        zoomLive?.observe(this) { zs -> if (zs != null) updateZoomUi(zs) }
        val range = cam.cameraInfo.exposureState.exposureCompensationRange
        evBar.max = max(0, range.upper - range.lower)
        exposureIndex = exposureIndex.coerceIn(range.lower, range.upper)
        evBar.progress = exposureIndex - range.lower
        cam.cameraControl.setExposureCompensationIndex(exposureIndex)
        updateEvLabel()
        applyFlash()
        updateTopButtons()
        setStatus(describeMode())
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
            .setAutoCancelDuration(4, TimeUnit.SECONDS)
            .build()
        cam.cameraControl.startFocusAndMetering(action)
        focusRing.animate().cancel()
        focusRing.x = x - focusRing.width / 2f
        focusRing.y = y - focusRing.height / 2f
        focusRing.visibility = View.VISIBLE
        focusRing.alpha = 1f
        focusRing.scaleX = 1.4f; focusRing.scaleY = 1.4f
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(180).withEndAction {
            focusRing.animate().alpha(0f).setStartDelay(900).setDuration(300).withEndAction { focusRing.visibility = View.GONE }
        }
    }

    // ------------------------------------------------------------------------------------------
    // shutter
    // ------------------------------------------------------------------------------------------

    private fun onShutter() {
        if (mode == Mode.VIDEO) { toggleRecording(); return }
        if (countingDown) {
            main.removeCallbacksAndMessages(null)
            countingDown = false
            countdownView.visibility = View.GONE
            return
        }
        if (busy) return
        if (timerSec > 0) startCountdown(timerSec) { capturePhoto() } else capturePhoto()
    }

    private fun startCountdown(seconds: Int, then: () -> Unit) {
        countingDown = true
        var left = seconds
        val tick = object : Runnable {
            override fun run() {
                if (left <= 0) {
                    countdownView.visibility = View.GONE
                    countingDown = false
                    then()
                    return
                }
                countdownView.text = left.toString()
                countdownView.visibility = View.VISIBLE
                left--
                main.postDelayed(this, 1000)
            }
        }
        main.post(tick)
    }

    private fun flashPreview() {
        previewView.animate().cancel()
        previewView.alpha = 0.25f
        previewView.animate().alpha(1f).setDuration(180).start()
    }

    private fun capturePhoto() {
        val cap = imageCapture ?: run { toast("Камера ещё запускается"); return }
        if (mode == Mode.STACK_HDR || mode == Mode.STACK_NIGHT) { captureStack(cap); return }
        busy = true
        setStatus("PROCESSING…")
        sound.play(MediaActionSound.SHUTTER_CLICK)
        flashPreview()
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "ALTE_${stamp()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Alte Cam")
        }
        val meta = ImageCapture.Metadata()
        meta.isReversedHorizontal = lensFacing == CameraSelector.LENS_FACING_FRONT
        val options = ImageCapture.OutputFileOptions
            .Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            .setMetadata(meta)
            .build()
        cap.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                busy = false
                setStatus("SAVED • ${mode.label}")
                outputFileResults.savedUri?.let { setLast(it, false) }
            }
            override fun onError(exception: ImageCaptureException) {
                busy = false
                setStatus("CAPTURE ERROR")
                toast("Ошибка съёмки: ${exception.message}")
            }
        })
    }

    @SuppressLint("MissingPermission")
    private fun toggleRecording() {
        val vc = videoCapture ?: run { toast("Видео ещё готовится"); return }
        val active = recording
        if (active != null) { active.stop(); return }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "ALTE_${stamp()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Alte Cam")
        }
        val out = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values).build()
        var pending = vc.output.prepareRecording(this, out)
        if (hasMic()) pending = pending.withAudioEnabled()
        sound.play(MediaActionSound.START_VIDEO_RECORDING)
        recording = pending.start(ContextCompat.getMainExecutor(this)) { ev ->
            when (ev) {
                is VideoRecordEvent.Start -> setRecordingUi(true)
                is VideoRecordEvent.Status -> {
                    val s = ev.recordingStats.recordedDurationNanos / 1_000_000_000L
                    setStatus("● REC %02d:%02d".format(Locale.US, s / 60, s % 60))
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    setRecordingUi(false)
                    sound.play(MediaActionSound.STOP_VIDEO_RECORDING)
                    if (ev.hasError()) {
                        setStatus("VIDEO ERROR")
                        toast("Ошибка записи видео (код ${ev.error})")
                    } else {
                        setStatus("VIDEO SAVED")
                        setLast(ev.outputResults.outputUri, true)
                    }
                }
                else -> {}
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    // Alte software stack (fallback when the device has no NIGHT / HDR extension)
    // ------------------------------------------------------------------------------------------

    private fun captureStack(cap: ImageCapture) {
        busy = true
        setStatus("CAPTURING…")
        sound.play(MediaActionSound.SHUTTER_CLICK)
        val state = camera?.cameraInfo?.exposureState
        val range = state?.exposureCompensationRange
        val stepEv = state?.exposureCompensationStep?.toFloat() ?: (1f / 3f)
        val hdr = mode == Mode.STACK_HDR
        val bracket: List<Int> = if (hdr) {
            val twoEv = Math.round(2f / stepEv).coerceAtLeast(1)
            listOf(-twoEv, 0, twoEv).map { (exposureIndex + it).coerceIn(range?.lower ?: -6, range?.upper ?: 6) }
        } else listOf(exposureIndex, exposureIndex, exposureIndex, exposureIndex)
        val frames = mutableListOf<Bitmap>()
        captureFrameAt(cap, bracket, 0, frames) {
            camera?.cameraControl?.setExposureCompensationIndex(exposureIndex)
            setStatus("FUSING…")
            executor.execute {
                try {
                    val result = if (hdr) FrameFusion.hdr(frames) else FrameFusion.average(frames)
                    val uri = saveBitmap(result)
                    if (frames.none { it === result }) result.recycle()
                    frames.forEach { if (!it.isRecycled) it.recycle() }
                    busy = false
                    setStatus(if (hdr) "ALTE HDR SAVED" else "ALTE NIGHT SAVED")
                    runOnUiThread { setLast(uri, false) }
                } catch (e: OutOfMemoryError) {
                    frames.forEach { if (!it.isRecycled) it.recycle() }
                    busy = false
                    setStatus("OUT OF MEMORY")
                } catch (e: Exception) {
                    frames.forEach { if (!it.isRecycled) it.recycle() }
                    busy = false
                    setStatus("PROCESSING ERROR")
                    runOnUiThread { toast("Ошибка обработки: ${e.localizedMessage}") }
                }
            }
        }
    }

    private fun captureFrameAt(cap: ImageCapture, bracket: List<Int>, index: Int, frames: MutableList<Bitmap>, done: () -> Unit) {
        if (index >= bracket.size) { done(); return }
        val future = camera?.cameraControl?.setExposureCompensationIndex(bracket[index])
        if (future == null) { captureSingle(cap, bracket, index, frames, done); return }
        future.addListener({ captureSingle(cap, bracket, index, frames, done) }, ContextCompat.getMainExecutor(this))
    }

    private fun captureSingle(cap: ImageCapture, bracket: List<Int>, index: Int, frames: MutableList<Bitmap>, done: () -> Unit) {
        cap.takePicture(ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining()); buffer.get(bytes)
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                    var sample = 1
                    while (max(bounds.outWidth / sample, bounds.outHeight / sample) > 2560) sample *= 2
                    val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                    val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                    if (decoded != null) {
                        val rotation = image.imageInfo.rotationDegrees
                        val bitmap = if (rotation != 0) {
                            val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, Matrix().apply { postRotate(rotation.toFloat()) }, true)
                            if (rotated !== decoded) decoded.recycle()
                            rotated
                        } else decoded
                        frames.add(bitmap)
                    }
                } finally { image.close() }
                if (frames.size == index + 1) captureFrameAt(cap, bracket, index + 1, frames, done)
                else {
                    busy = false
                    camera?.cameraControl?.setExposureCompensationIndex(exposureIndex)
                    setStatus("DECODE ERROR")
                }
            }
            override fun onError(exception: ImageCaptureException) {
                camera?.cameraControl?.setExposureCompensationIndex(exposureIndex)
                busy = false
                frames.forEach { if (!it.isRecycled) it.recycle() }
                setStatus("CAPTURE ERROR")
                toast("Ошибка съёмки: ${exception.message}")
            }
        })
    }

    private fun saveBitmap(bitmap: Bitmap): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "ALTE_${stamp()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Alte Cam")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("MediaStore insert failed")
        contentResolver.openOutputStream(uri)?.use { out ->
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 96, out)) error("JPEG encode failed")
        } ?: error("Cannot open output stream")
        return uri
    }

    // ------------------------------------------------------------------------------------------
    // last shot thumbnail
    // ------------------------------------------------------------------------------------------

    private fun setLast(uri: Uri, video: Boolean) {
        lastUri = uri
        lastIsVideo = video
        executor.execute {
            val bmp = try { contentResolver.loadThumbnail(uri, Size(220, 220), null) } catch (e: Exception) { null }
            if (bmp != null) runOnUiThread { thumb.setImageBitmap(bmp) }
        }
    }

    private fun openLast() {
        val uri = lastUri ?: run { toast("Снимки: Галерея → Pictures → Alte Cam"); return }
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, if (lastIsVideo) "video/*" else "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: ActivityNotFoundException) {
            toast("Нет приложения для просмотра")
        }
    }
}

/** Rule-of-thirds grid + horizon level, drawn above the preview. */
private class OverlayView(context: Context) : View(context) {
    var showGrid: Boolean = false
        set(value) { field = value; invalidate() }
    private var roll = 0f
    private var levelOn = false
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x88FFFFFF.toInt(); strokeWidth = 2f }
    private val levelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 4f; strokeCap = Paint.Cap.ROUND }

    fun setLevel(deg: Float, on: Boolean) { roll = deg; levelOn = on; invalidate() }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (showGrid) {
            for (i in 1..2) {
                canvas.drawLine(w * i / 3f, 0f, w * i / 3f, h, gridPaint)
                canvas.drawLine(0f, h * i / 3f, w, h * i / 3f, gridPaint)
            }
        }
        if (levelOn) {
            val level = abs(roll) < 1f
            levelPaint.color = if (level) 0xFFFFD60A.toInt() else 0xCCFFFFFF.toInt()
            val half = if (level) w * 0.18f else w * 0.12f
            canvas.save()
            canvas.rotate(-roll, w / 2f, h / 2f)
            canvas.drawLine(w / 2f - half, h / 2f, w / 2f + half, h / 2f, levelPaint)
            canvas.restore()
        }
    }
}

/**
 * Global translational alignment + robust multi-frame fusion (software fallback).
 * Lightweight approximation, not optical-flow alignment; the RAW+ screen is the high-quality path.
 */
private object FrameFusion {
    fun average(frames: List<Bitmap>): Bitmap = fuse(frames, hdr = false)
    fun hdr(frames: List<Bitmap>): Bitmap = fuse(frames, hdr = true)

    private fun fuse(frames: List<Bitmap>, hdr: Boolean): Bitmap {
        require(frames.isNotEmpty())
        if (frames.size == 1) return BoostProcessor.enhance(frames[0])
        val w = frames.minOf { it.width }
        val h = frames.minOf { it.height }
        val normalized = frames.map { b ->
            if (b.width == w && b.height == h) b else Bitmap.createScaledBitmap(b, w, h, true)
        }
        val ref = normalized[normalized.size / 2]
        val refPixels = IntArray(w * h).also { ref.getPixels(it, 0, w, 0, 0, w, h) }
        val aligned = normalized.mapIndexed { index, bitmap ->
            if (index == normalized.size / 2) refPixels else {
                val pixels = IntArray(w * h).also { bitmap.getPixels(it, 0, w, 0, 0, w, h) }
                val shift = estimateTranslation(refPixels, pixels, w, h)
                translate(pixels, w, h, shift.first, shift.second)
            }
        }
        val output = IntArray(w * h)
        val centerFrame = aligned[aligned.size / 2]
        for (i in output.indices) {
            val center = centerFrame[i]
            val cr = Color.red(center).toDouble()
            val cg = Color.green(center).toDouble()
            val cb = Color.blue(center).toDouble()
            val centerLum = .2126 * cr + .7152 * cg + .0722 * cb
            var r = 0.0; var g = 0.0; var b = 0.0; var total = 0.0
            for (frame in aligned) {
                val c = frame[i]
                val pr = Color.red(c).toDouble(); val pg = Color.green(c).toDouble(); val pb = Color.blue(c).toDouble()
                val lum = .2126 * pr + .7152 * pg + .0722 * pb
                val motionDiff = abs(lum - centerLum)
                // Reject likely moving-object pixels instead of blending ghost trails.
                val motionWeight = 1.0 / (1.0 + (motionDiff / 22.0).pow(2.0))
                val exposureWeight = if (hdr) {
                    val normalizedLum = lum / 255.0
                    max(.08, 1.0 - abs(normalizedLum - .48) * 1.75)
                } else 1.0
                val weight = motionWeight * exposureWeight
                r += pr * weight; g += pg * weight; b += pb * weight; total += weight
            }
            val rr = (r / total).coerceIn(0.0, 255.0).toInt()
            val gg = (g / total).coerceIn(0.0, 255.0).toInt()
            val bb = (b / total).coerceIn(0.0, 255.0).toInt()
            output[i] = if (hdr) toneMap(rr, gg, bb) else Color.rgb(rr, gg, bb)
        }
        val fused = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        fused.setPixels(output, 0, w, 0, 0, w, h)
        normalized.forEach { if (it !== ref && frames.none { original -> original === it }) it.recycle() }
        return BoostProcessor.enhance(fused).also { if (it !== fused) fused.recycle() }
    }

    private fun estimateTranslation(reference: IntArray, candidate: IntArray, w: Int, h: Int): Pair<Int, Int> {
        val scale = max(1, max(w, h) / 320)
        val radius = max(2, 8 / scale)
        var bestX = 0; var bestY = 0; var best = Double.MAX_VALUE
        val step = max(2, 5 * scale)
        for (dy in -radius..radius) for (dx in -radius..radius) {
            var error = 0.0; var count = 0
            var y = 12 * scale
            while (y < h - 12 * scale) {
                var x = 12 * scale
                while (x < w - 12 * scale) {
                    val a = reference[y * w + x]
                    val b = candidate[(y + dy * scale).coerceIn(0, h - 1) * w + (x + dx * scale).coerceIn(0, w - 1)]
                    val la = .2126 * Color.red(a) + .7152 * Color.green(a) + .0722 * Color.blue(a)
                    val lb = .2126 * Color.red(b) + .7152 * Color.green(b) + .0722 * Color.blue(b)
                    error += abs(la - lb); count++
                    x += step
                }
                y += step
            }
            val score = if (count == 0) Double.MAX_VALUE else error / count
            if (score < best) { best = score; bestX = dx * scale; bestY = dy * scale }
        }
        return Pair(bestX, bestY)
    }

    private fun translate(src: IntArray, w: Int, h: Int, dx: Int, dy: Int): IntArray {
        val out = IntArray(src.size)
        for (y in 0 until h) for (x in 0 until w) {
            val sx = (x + dx).coerceIn(0, w - 1)
            val sy = (y + dy).coerceIn(0, h - 1)
            out[y * w + x] = src[sy * w + sx]
        }
        return out
    }

    private fun toneMap(r: Int, g: Int, b: Int): Int {
        fun map(v: Int): Int {
            val x = v / 255.0
            val compressed = (x * (1.0 + 0.18)) / (x + 0.18)
            return (compressed * 255.0).coerceIn(0.0, 255.0).toInt()
        }
        return Color.rgb(map(r), map(g), map(b))
    }
}

/** Conservative edge-aware denoise + sharpen; not a trained neural network. */
private object BoostProcessor {
    fun enhance(source: Bitmap): Bitmap {
        val w = source.width; val h = source.height
        val src = IntArray(w * h); source.getPixels(src, 0, w, 0, 0, w, h)
        val out = src.copyOf()
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x; val c = src[i]
            val cr = Color.red(c); val cg = Color.green(c); val cb = Color.blue(c)
            var rr = 0.0; var gg = 0.0; var bb = 0.0; var total = 0.0
            for (dy in -1..1) for (dx in -1..1) {
                val p = src[(y + dy) * w + x + dx]
                val dist = (abs(Color.red(p) - cr) + abs(Color.green(p) - cg) + abs(Color.blue(p) - cb)) / 3.0
                val wt = if (dx == 0 && dy == 0) 1.0 else 1.0 / (1.0 + dist / 24.0)
                rr += Color.red(p) * wt; gg += Color.green(p) * wt; bb += Color.blue(p) * wt; total += wt
            }
            val r0 = (rr / total); val g0 = (gg / total); val b0 = (bb / total)
            val up = src[i - w]; val dn = src[i + w]; val lf = src[i - 1]; val rt = src[i + 1]
            val sr = r0 + (4 * r0 - Color.red(up) - Color.red(dn) - Color.red(lf) - Color.red(rt)) * 0.28
            val sg = g0 + (4 * g0 - Color.green(up) - Color.green(dn) - Color.green(lf) - Color.green(rt)) * 0.28
            val sb = b0 + (4 * b0 - Color.blue(up) - Color.blue(dn) - Color.blue(lf) - Color.blue(rt)) * 0.28
            val lum = .2126 * r0 + .7152 * g0 + .0722 * b0
            val sat = 1.045
            val r = (lum + (sr - lum) * sat).toInt().coerceIn(0, 255)
            val g = (lum + (sg - lum) * sat).toInt().coerceIn(0, 255)
            val b = (lum + (sb - lum) * sat).toInt().coerceIn(0, 255)
            out[i] = Color.rgb(r, g, b)
        }
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { it.setPixels(out, 0, w, 0, 0, w, h) }
    }
}
