package com.altecam.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PostProcessorTests {
    private fun grey(v: Int) = (0xFF shl 24) or (v shl 16) or (v shl 8) or v

    @Test fun flatImageIsUnchanged() {
        val w = 16; val h = 16
        val img = IntArray(w * h) { grey(100) }
        val copy = img.copyOf()
        PostProcessor.sharpen(img, w, h, 0.8f)
        assertTrue(img.contentEquals(copy))
    }

    @Test fun edgeContrastIncreases() {
        val w = 16; val h = 8
        val img = IntArray(w * h) { if (it % w < 8) grey(80) else grey(160) }
        PostProcessor.sharpen(img, w, h, 0.8f)
        val left = img[3 * w + 7] and 0xFF
        val right = img[3 * w + 8] and 0xFF
        assertTrue("left=$left right=$right", left < 80 && right > 160)
    }

    @Test fun vibranceKeepsGreyAndBoostsMuted() {
        val g = intArrayOf(grey(120))
        PostProcessor.vibrance(g, 1, 1, 0.3f)
        assertEquals(120, g[0] and 0xFF)
        val muted = intArrayOf((0xFF shl 24) or (130 shl 16) or (120 shl 8) or 110)
        PostProcessor.vibrance(muted, 1, 1, 0.3f)
        assertTrue(((muted[0] shr 16) and 0xFF) - (muted[0] and 0xFF) > 20)
    }
}
